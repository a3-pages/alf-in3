# ALF - Chrome Extension

- revision: 1.1.0-8-ga0c662c
- deply: 