/** Matches stepUrl (path + query, `{id}` = any segment) against currentUrl; extra query params in currentUrl are allowed. */
function evaluateCondition(condition) {
  if (!condition) return true;
  const vw = document.documentElement.clientWidth || window.innerWidth;
  const vh = document.documentElement.clientHeight || window.innerHeight;
  // fast path: handle simple "viewport.width/height OP number" patterns without eval
  const m = String(condition).trim().match(/^viewport\.(width|height)\s*(>=|<=|>|<|===|==|!==|!=)\s*(\d+)$/);
  if (m) {
    const val = m[1] === 'width' ? vw : vh;
    const threshold = Number(m[3]);
    let result;
    switch (m[2]) {
      case '>':   result = val >   threshold; break;
      case '<':   result = val <   threshold; break;
      case '>=':  result = val >=  threshold; break;
      case '<=':  result = val <=  threshold; break;
      case '===': case '==':  result = val === threshold; break;
      case '!==': case '!=':  result = val !== threshold; break;
      default:    result = true;
    }
    console.log(`ALF condition [${condition}] → vw=${vw} vh=${vh} → ${result}`);
    return result;
  }
  try {
    const viewport = { width: vw, height: vh };
    const device = '';
    const result = Boolean(new Function('device', 'viewport', `return (${condition})`)(device, viewport));
    console.log(`ALF condition (eval) [${condition}] → vw=${vw} vh=${vh} → ${result}`);
    return result;
  } catch (e) {
    console.warn('ALF evaluateCondition: failed to evaluate condition', condition, e);
    return true;
  }
}

// Steps have no `url`: the expected page is the `assert.before` urlMatches("...") line.
function getStepUrlPattern(step) {
  if (!step || typeof step !== "object") return null;
  const before = step.assert?.before;
  const lines = Array.isArray(before) ? before : [];
  for (const raw of lines) {
    const line = String(raw).trim();
    const m = /^urlMatches\(\s*["']([^"']+)["']\s*\)$/.exec(line);
    if (m) return m[1];
  }
  return null;
}

// The login step is recognised by its shape: it fills the preset's auth_user/auth_pass via the `#preset` marker.
function isLoginStep(step) {
  if (!step || typeof step !== "object") return false;
  const map = step.map;
  if (!map || typeof map !== "object") return false;
  return Object.entries(map).some(([key, value]) => {
    if (!/#preset$/i.test(String(key))) return false;
    return value === "auth_user" || value === "auth_pass";
  });
}

function urlMatchesStep(currentUrl, stepUrl) {
  if (!currentUrl || !stepUrl) return false;
  try {
    const curr = new URL(currentUrl);
    const currentPath = curr.pathname;
    const currentSearch = curr.search || "";

    // A bare trailing "#" is usually gone once the SPA settles; strip it so it cannot force an impossible suffix match.
    const stepUrlNoEmptyHash = stepUrl.replace(/#$/, "");

    const qPos = stepUrlNoEmptyHash.indexOf("?");
    const stepPath = qPos >= 0 ? stepUrlNoEmptyHash.slice(0, qPos) : stepUrlNoEmptyHash;
    const stepSearch = qPos >= 0 ? stepUrlNoEmptyHash.slice(qPos) : "";

    const stepSegments = stepPath.split("/").filter(Boolean);
    const currSegments = currentPath.split("/").filter(Boolean);
    if (stepSegments.length !== currSegments.length) return false;

    const idIndex = stepSegments.indexOf("{id}");
    const normalizedCurr = currSegments.map((seg, i) => (i === idIndex ? "{id}" : seg)).join("/");
    const normalizedPath = "/" + normalizedCurr + currentSearch;
    const stepPathAndQuery = (stepPath.startsWith("/") ? stepPath : "/" + stepPath) + stepSearch;

    if (stepPath.startsWith("/")) {
      if (!normalizedPath.startsWith(stepPath)) {
        return false;
      }
    }

    if (!stepSearch) {
      return true;
    }

    const stepParams = new URLSearchParams(stepSearch);
    const currParams = new URLSearchParams(currentSearch);

    for (const [key, value] of stepParams.entries()) {
      if (!currParams.has(key)) return false;
      const isPlaceholder = value.startsWith("{") && value.endsWith("}");
      if (value !== "" && !isPlaceholder && currParams.get(key) !== value) {
        return false;
      }
    }

    return true;
  } catch (e) {
    return false;
  }
}

// Remembers which step already autofilled on which URL: several steps can share one URL (SPA wizard), so the URL alone is not enough.
let lastAutofillUrl = null;
let lastAutofillStepIndex = null;
const PENDING_LOGIN_AUTOFILL_KEY = "alfPendingLoginAutofill";

function setPendingLoginAutofill(scenario, stepIndex) {
  try {
    chrome.storage.local.set(
      {
        [PENDING_LOGIN_AUTOFILL_KEY]: {
          steps: scenario,
          stepIndex,
          createdAt: Date.now(),
        },
      },
      () => {},
    );
  } catch {
    // ignore
  }
}

function runPendingLoginAutofillOnLoad() {
  try {
    chrome.storage.local.get([PENDING_LOGIN_AUTOFILL_KEY], (result) => {
      const pending = result && result[PENDING_LOGIN_AUTOFILL_KEY];
      if (!pending || typeof pending !== "object") return;

      const scenario = pending.steps;
      const stepIndex = pending.stepIndex;
      const createdAt = pending.createdAt || 0;

      // Bezpečnostná poistka proti starému pending stavu.
      if (Date.now() - createdAt > 2 * 60 * 1000) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      const step = scenario[stepIndex];
      if (!isLoginStep(step)) {
        chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        return;
      }

      Promise.resolve(autofillScenarioForCurrentUrl(scenario, stepIndex))
        .catch(() => {
          // ignore
        })
        .finally(() => {
          chrome.storage.local.remove(PENDING_LOGIN_AUTOFILL_KEY, () => {});
        });
    });
  } catch {
    // ignore
  }
}

// How long to wait for a mapped element that is not in the DOM yet (e.g. rows of async-loaded tables).
const ALF_ELEMENT_WAIT_MS = 3000;
const ALF_ELEMENT_POLL_INTERVAL_MS = 150;

function __alfQueryByTestIdOrId(lookupKey) {
  const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(lookupKey) : lookupKey;
  return document.querySelector(`[data-test-id="${selectorId}"]`) || document.getElementById(lookupKey);
}

function __alfWarnDuplicateTestId(lookupKey) {
  const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(lookupKey) : lookupKey;
  const count = document.querySelectorAll(`[data-test-id="${selectorId}"]`).length;
  if (count > 1) {
    console.warn(`[ALF] data-test-id "${lookupKey}" found ${count}x – using the first one`);
  }
}

function __alfWaitForElement(lookupKey, timeoutMs) {
  return new Promise((resolve) => {
    const existing = __alfQueryByTestIdOrId(lookupKey);
    if (existing) {
      resolve(existing);
      return;
    }
    let elapsed = 0;
    const timer = setInterval(() => {
      elapsed += ALF_ELEMENT_POLL_INTERVAL_MS;
      const el = __alfQueryByTestIdOrId(lookupKey);
      if (el || elapsed >= timeoutMs) {
        clearInterval(timer);
        resolve(el || null);
      }
    }, ALF_ELEMENT_POLL_INTERVAL_MS);
  });
}

/** Fills the step's map if the current URL matches the step at stepIndex; steps run strictly in sequence, never looked up by URL. */
async function autofillScenarioForCurrentUrl(scenario, stepIndex) {
  if (!Array.isArray(scenario) || !scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }
  if (stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    return { filledCount: 0, matchedStepUrl: null };
  }

  const currentUrl = location.href;
  const step = scenario[stepIndex];
  if (!step || !step.map || typeof step.map !== "object") {
    return { filledCount: 0, matchedStepUrl: null };
  }

  // New-format steps often have no urlMatches(...); verify the URL only when a pattern is present, never require one to fill the map.
  const stepUrl = getStepUrlPattern(step);
  if (stepUrl && !urlMatchesStep(currentUrl, stepUrl)) {
    console.error("ALF scenario – URL nesedí na stepIndex", {
      stepIndex,
      expectedStepUrl: stepUrl,
      currentUrl,
    });
    throw new Error("ALF scenario – URL v kroku scenára sa nezhoduje s aktuálnou stránkou");
  }

  {
    const entries = Object.entries(step.map);
    let filledCount = 0;
    const missingKeys = [];

    const fillEntry = async (dataTestId, value) => {
      if (dataTestId == null || dataTestId === "") return false;

      const rawKey = String(dataTestId);
      const hashPos = rawKey.indexOf("#");
      const lookupKey = hashPos >= 0 ? rawKey.slice(0, hashPos) : rawKey;
      const suffix = hashPos >= 0 ? rawKey.slice(hashPos + 1).toLowerCase() : "";
      const markers = suffix
        ? suffix
            .split(";")
            .map((s) => s.trim())
            .filter(Boolean)
        : [];
      const isLabelKeyLocal = suffix === "label";
      const isToggleKeyLocal = markers.includes("toggle");
      const isSearchKeyLocal = markers.includes("search");
      const isComboboxKeyLocal = markers.includes("combobox");
      const isComboboxFirstKeyLocal = markers.includes("combobox-first");
      const attachmentMarker = markers.find((m) => m.startsWith("attachment("));
      const attachmentFile = attachmentMarker
        ? attachmentMarker.replace(/^attachment\(['"]?/, "").replace(/['"]?\)$/, "")
        : null;

      if (isLabelKeyLocal) return false;

      if (attachmentFile) return "attachment";

      let el = __alfQueryByTestIdOrId(lookupKey);
      if (!el) {
        // Rows of async-loaded tables render after the step's URL already matches, so wait briefly instead of giving up.
        el = await __alfWaitForElement(lookupKey, ALF_ELEMENT_WAIT_MS);
      }
      if (el) __alfWarnDuplicateTestId(lookupKey);
      if (!el) {
        console.warn(
          `ALF autofill – element pre "${lookupKey}" sa nenašiel v DOM ani po ${ALF_ELEMENT_WAIT_MS}ms čakaní (map záznam preskočený)`,
        );
        missingKeys.push(lookupKey);
        return false;
      }

      const valueStr = value != null ? String(value) : "";

      if (el instanceof HTMLInputElement) {
        const t = el.type ? el.type.toLowerCase() : "";

        if (t === "checkbox" || t === "radio") {
          if (typeof el.click === "function") {
            el.click();
          }

          filledCount++;
          return true;
        } else {
          el.value = valueStr;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else if (el instanceof HTMLTextAreaElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el instanceof HTMLSelectElement) {
        el.value = valueStr;
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if ("value" in el) {
        el.value = valueStr;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        if (el.querySelector) {
          // Toggle: vnorený checkbox/radio/role=checkbox
          if (isToggleKeyLocal) {
            const innerToggle = el.querySelector(
              'input[type="checkbox"], input[type="radio"], [role="checkbox"]',
            );
            if (innerToggle && typeof innerToggle.click === "function") {
              innerToggle.click();
              filledCount++;
              return true;
            }
          }

          // Combobox (explicit #combobox marker): otvor dropdown, potom klikni na opciu
          if (isComboboxKeyLocal) {
            // Clicking an already selected option deselects it (multiselect canDeselect),
            // so an option that is preselected is left alone.
            const wantedValue = String(value != null ? value : "").trim().toLowerCase();
            const alreadySelected = Array.prototype.slice
              .call(el.querySelectorAll('[role="option"][aria-selected="true"]'))
              .some((opt) => {
                const labelText = (opt.getAttribute("aria-label") || opt.textContent || "").trim().toLowerCase();
                const idParts = (opt.id || "").split("-option-");
                const idValue = idParts.length === 2 ? idParts[1].trim().toLowerCase() : "";
                return wantedValue === labelText || (idValue && wantedValue === idValue);
              });
            if (alreadySelected) {
              filledCount++;
              return true;
            }

            const comboboxRoot =
              el.getAttribute("role") === "combobox"
                ? el
                : el.querySelector('[role="combobox"], .multiselect-wrapper');
            if (comboboxRoot && typeof comboboxRoot.click === "function") {
              comboboxRoot.click();
            }
            // Otvorenie dropdownu je async – opciu klikneme po renderovaní
            setTimeout(() => {
              const listbox =
                el.querySelector(".multiselect-options") ||
                el.querySelector('[role="listbox"]') ||
                (comboboxRoot && comboboxRoot.nextElementSibling);
              if (!listbox) return;
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const wanted = valueStr.trim().toLowerCase();
              const target = options.find((opt) => {
                const labelText =
                  (opt.getAttribute && opt.getAttribute("aria-label")) ||
                  opt.textContent ||
                  "";
                const id = opt.id || "";
                let idValue = "";
                const idParts = id.split("-option-");
                if (idParts.length === 2) idValue = idParts[1];
                return (
                  wanted === labelText.trim().toLowerCase() ||
                  (idValue && wanted === idValue.trim().toLowerCase())
                );
              });
              if (target && typeof target.click === "function") {
                target.click();
              }
            }, 400);
            filledCount++;
            return true;
          }

          // Combobox-first (explicit #combobox-first marker): otvor dropdown, klikni prvú dostupnú opciu
          if (isComboboxFirstKeyLocal) {
            const comboboxRoot =
              el.getAttribute("role") === "combobox"
                ? el
                : el.querySelector('[role="combobox"], .multiselect-wrapper');
            if (comboboxRoot && typeof comboboxRoot.click === "function") {
              comboboxRoot.click();
            }
            // Otvorenie dropdownu je async – opciu klikneme po renderovaní
            setTimeout(() => {
              const listbox =
                el.querySelector(".multiselect-options") ||
                el.querySelector('[role="listbox"]') ||
                (comboboxRoot && comboboxRoot.nextElementSibling);
              if (!listbox) return;
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const target = options.find((opt) => {
                const disabled =
                  (opt.getAttribute && opt.getAttribute("aria-disabled") === "true") ||
                  opt.disabled ||
                  (opt.classList && opt.classList.contains("is-disabled"));
                return !disabled;
              });
              if (target && typeof target.click === "function") {
                target.click();
              }
            }, 400);
            filledCount++;
            return true;
          }

          // Search: vnorený textový/combobox input + tlačidlo "vyhladat"
          if (isSearchKeyLocal) {
            const searchInput =
              el.querySelector('input[type="text"][role="combobox"]') ||
              el.querySelector('input[type="search"]') ||
              el.querySelector('input[type="text"]');

            if (searchInput) {
              searchInput.value = valueStr;
              searchInput.dispatchEvent(new Event("input", { bubbles: true }));
              searchInput.dispatchEvent(new Event("change", { bubbles: true }));
            }

            const searchButton = el.querySelector('[data-test-id="vyhladat"]');
            if (searchButton && typeof searchButton.click === "function") {
              searchButton.click();
            }

            // Po vyhľadaní (po krátkom oneskorení) automaticky zvolíme PRVÚ ne-disable-nutú možnosť
            setTimeout(() => {
              const listbox =
                el.querySelector(".multiselect-options") ||
                el.querySelector('[role="listbox"]');
              if (!listbox) return;

              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );

              const target = options.find(
                (opt) =>
                  !opt.classList || !opt.classList.contains("is-disabled"),
              );

              if (target && typeof target.click === "function") {
                target.click();
              }
            }, 1000);

            filledCount++;
            return true;
          }

          // Combobox (custom multiselect) – vyber možnosť podľa textu/aria-label
          const comboboxRoot =
            el.getAttribute("role") === "combobox"
              ? el
              : el.querySelector('[role="combobox"], .multiselect-wrapper');
          if (comboboxRoot) {
            const listbox =
              el.querySelector(".multiselect-options") ||
              el.querySelector('[role="listbox"]') ||
              comboboxRoot.nextElementSibling;
            if (listbox) {
              const options = Array.prototype.slice.call(
                listbox.querySelectorAll('[role="option"], li'),
              );
              const target = options.find((opt) => {
                const labelText =
                  (opt.getAttribute && opt.getAttribute("aria-label")) ||
                  opt.textContent ||
                  "";
                const id = opt.id || "";
                // napr. "...-multiselect-option-vydatazenaty" -> "vydatazenaty"
                let idValue = "";
                const idParts = id.split("-option-");
                if (idParts.length === 2) {
                  idValue = idParts[1];
                }

                const wanted = valueStr.trim().toLowerCase();
                const labelNorm = labelText.trim().toLowerCase();
                const idNorm = idValue.trim().toLowerCase();

                return wanted === labelNorm || (idNorm && wanted === idNorm);
              });

              if (target && typeof target.click === "function") {
                target.click();
                filledCount++;
                return true;
              }
            }
          }
        }

        el.textContent = valueStr;
      }
      filledCount++;
      return true;
    };

    // Each #toggle may unlock more fields, so wait 1s after it; the wait must be per toggle, otherwise a later toggle ran at once and re-filled the rest of the map.
    const processEntryAt = (index) =>
      new Promise((resolveEntry) => {
        (async () => {
        if (index >= entries.length) {
          resolveEntry();
          return;
        }
        const [dataTestId, value] = entries[index];
        const keyStr = dataTestId != null ? String(dataTestId) : "";
        const hashIndex = keyStr.indexOf("#");
        const suffix = hashIndex >= 0 ? keyStr.slice(hashIndex + 1).toLowerCase() : "";
        const markers = suffix
          ? suffix
              .split(";")
              .map((s) => s.trim())
              .filter(Boolean)
          : [];
        const isLabelKey = suffix === "label";
        const isToggleKey = markers.includes("toggle");
        const isComboboxKey = markers.includes("combobox");
        const isComboboxFirstKey = markers.includes("combobox-first");
        const attachmentMarkerOuter = markers.find((m) => m.startsWith("attachment("));
        const attachmentFileOuter = attachmentMarkerOuter
          ? attachmentMarkerOuter.replace(/^attachment\(['"]?/, "").replace(/['"]?\)$/, "")
          : null;

        const next = () => {
          if (index < entries.length - 1) {
            processEntryAt(index + 1).then(resolveEntry);
          } else {
            resolveEntry();
          }
        };

        if (attachmentFileOuter) {
          const lookupKey = keyStr.slice(0, hashIndex);
          const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(lookupKey) : lookupKey;
          const inputEl =
            document.querySelector(`[data-test-id="${selectorId}"] input[type="file"]`) ||
            document.querySelector(`[data-test-id="${selectorId}"]`) ||
            document.getElementById(lookupKey);

          const fileUrl = chrome.runtime.getURL(`storage/${attachmentFileOuter}`);
          fetch(fileUrl)
            .then((res) => res.arrayBuffer())
            .then((buffer) => {
              const file = new File([buffer], attachmentFileOuter);
              const dt = new DataTransfer();
              dt.items.add(file);
              const target = inputEl && inputEl.type === "file" ? inputEl : inputEl && inputEl.querySelector('input[type="file"]');
              if (target) {
                target.files = dt.files;
                target.dispatchEvent(new Event("change", { bubbles: true }));
                filledCount++;
              } else {
                console.warn("ALF attachment – nenašiel sa input[type=file] pre", lookupKey);
                missingKeys.push(lookupKey);
              }
            })
            .catch((e) => console.error("ALF attachment – chyba pri načítaní súboru:", attachmentFileOuter, e))
            .finally(next);
          return;
        }

        if (!isLabelKey) {
          try {
            await fillEntry(dataTestId, value);
          } catch (e) {
            console.error("ALF scenario autofill – fill error", e);
          }
        }

        if ((isToggleKey || isComboboxKey || isComboboxFirstKey) && index < entries.length - 1) {
          setTimeout(() => {
            processEntryAt(index + 1).then(resolveEntry);
          }, 600);
        } else {
          next();
        }
        })();
      });

    await processEntryAt(0);

  if (filledCount > 0) {
    lastAutofillUrl = currentUrl;
    lastAutofillStepIndex = stepIndex;
    return { filledCount, matchedStepUrl: stepUrl, missingKeys };
  }

  return { filledCount: 0, matchedStepUrl: null, missingKeys };
  }
}

function setNestedScopeValue(target, dottedPath, value) {
  if (!target || typeof target !== "object") return;
  if (!dottedPath) return;

  const parts = String(dottedPath)
    .split(".")
    .map((part) => part.trim())
    .filter(Boolean);

  if (parts.length === 0) return;

  let cursor = target;
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(part)) return;

    const isLast = i === parts.length - 1;
    if (isLast) {
      cursor[part] = value;
      return;
    }

    if (!cursor[part] || typeof cursor[part] !== "object") {
      cursor[part] = {};
    }
    cursor = cursor[part];
  }
}

// `assert` is { before, after }. Without a phase the whole assert block is
// returned unchanged.
function getPhaseAssertions(assertions, phase) {
  if (phase !== "before" && phase !== "after") return assertions;
  const list = assertions?.[phase];
  return Array.isArray(list) ? list : [];
}

function createAssertionContext(step, scenario, stepIndex) {
  const map = step && step.map && typeof step.map === "object" ? step.map : {};
  const data = {};

  for (const [key, value] of Object.entries(map)) {
    setNestedScopeValue(data, key, value);
  }

  return {
    step: step && typeof step === "object" ? step : {},
    steps: Array.isArray(scenario) ? scenario : [],
    map,
    data,
    stepIndex: Number.isInteger(stepIndex) ? stepIndex : -1,
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (
    !message ||
    (message.type !== "ALF_RUN_SCENARIO_ACTION" &&
      message.type !== "ALF_RUN_ASSERTIONS" &&
      message.type !== "ALF_RUN_MAP")
  ) {
    return;
  }

  const scenario = message.steps;
  const stepIndex = message.stepIndex;
  if (!Array.isArray(scenario) || stepIndex == null || stepIndex < 0 || stepIndex >= scenario.length) {
    sendResponse && sendResponse({ ok: false, reason: "missing_scenario_or_index" });
    return;
  }

  const stepForClick = scenario[stepIndex];

  if (message.type === "ALF_RUN_MAP") {
    Promise.resolve(autofillScenarioForCurrentUrl(scenario, stepIndex))
      .then((result) => {
        sendResponse && sendResponse({ ok: true, filledCount: result.filledCount, mapMissing: result.missingKeys || [] });
      })
      .catch((e) => {
        console.error("ALF content script – map zlyhal:", e);
        sendResponse && sendResponse({ ok: false, error: String(e) });
      });
    return true;
  }

  if (message.type === "ALF_RUN_ASSERTIONS") {
    try {
      const assertContext = createAssertionContext(stepForClick, scenario, stepIndex);
      const assertResults = runAssertions(getPhaseAssertions(stepForClick.assert, message.phase), assertContext);
      sendResponse && sendResponse({ ok: true, assertResults });
    } catch (e) {
      console.error("ALF content script – chyba pri vyhodnocovaní assertácií:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return true;
  }

  if (stepForClick.condition === undefined || stepForClick.condition === null) {
    console.log(`ALF step [${stepIndex}] action=${stepForClick.action || stepForClick.actions} – no condition, running`);
  }
  if (!evaluateCondition(stepForClick.condition)) {
    console.log(`ALF step [${stepIndex}] action=${stepForClick.action || stepForClick.actions} – skipped by condition`);
    sendResponse && sendResponse({ ok: true, skipped: true });
    return true;
  }

  const actionName = stepForClick.action || stepForClick.actions;
  if (!actionName) {
    sendResponse && sendResponse({ ok: false, reason: "missing_action" });
    return;
  }

  try {
    // Autofill is async (waits on the #toggle/#combobox timeout chain); wait for it before clicking the action.
    const alreadyAutofilledThisStep =
      location.href === lastAutofillUrl && stepIndex === lastAutofillStepIndex;
    const autofillReadyPromise =
      !alreadyAutofilledThisStep
        ? Promise.resolve(autofillScenarioForCurrentUrl(scenario, stepIndex)).catch((e) => {
            console.error("ALF content script – autofill zlyhal:", e);
            return { filledCount: 0, matchedStepUrl: null };
          })
        : Promise.resolve({ filledCount: 0, matchedStepUrl: null });

    const actionStr = String(actionName);
    const actionHashPos = actionStr.indexOf("#");
    const actionSuffix = actionHashPos >= 0 ? actionStr.slice(actionHashPos + 1).toLowerCase() : "";
    const actionAttachmentMarker = actionSuffix.startsWith("attachment(") ? actionSuffix : null;
    const actionAttachmentFile = actionAttachmentMarker
      ? actionAttachmentMarker.replace(/^attachment\(['"]?/, "").replace(/['"]?\)$/, "")
      : null;

    autofillReadyPromise.then((autofillResult) => {
      const handledAutofill = autofillResult.filledCount > 0;
      const mapMissing = autofillResult.missingKeys || [];

      if (actionAttachmentFile) {
        const actionLookupKey = actionHashPos >= 0 ? actionStr.slice(0, actionHashPos) : actionStr;
        const selectorId = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(actionLookupKey) : actionLookupKey;
        const wrapperEl =
          document.querySelector(`[data-test-id="${selectorId}"]`) ||
          document.getElementById(actionLookupKey);
        const uploadTrigger =
          wrapperEl &&
          (wrapperEl instanceof HTMLInputElement
            ? wrapperEl
            : wrapperEl.querySelector('input[type="file"], button, [role="button"]') || wrapperEl);
        if (uploadTrigger && typeof uploadTrigger.click === "function") {
          uploadTrigger.click();
        }
        sendResponse && sendResponse({ ok: true, found: !!wrapperEl, clicked: !!uploadTrigger, autofilled: handledAutofill, mapMissing, attachmentManual: true, dialogAllowed: navigator.userActivation ? navigator.userActivation.isActive : true });
        return;
      }

      const doActionClick = (phase) => {
        const actionKey = actionStr;
        const selector = `[data-test-id="${actionKey}"]`;
        const all = Array.prototype.slice.call(document.querySelectorAll("[data-test-id]"));
        let matches = Array.prototype.slice.call(document.querySelectorAll(selector));
        if (matches.length === 0) {
          const byId = document.getElementById(actionKey);
          if (byId) matches = [byId];
        }

        let clicked = false;
        // A hidden copy of the same data-test-id (e.g. the mobile sidebar) can come first in the DOM, so a visible one is preferred.
        const visibleMatches = matches.filter(alfIsVisible);
        const target = visibleMatches[0] || matches[0];
        if (matches.length > 1) {
          console.warn(`[ALF] data-test-id "${actionKey}" found ${matches.length}x – clicking the ${visibleMatches.length ? "first visible" : "first"} one`);
        }
        if (target) {
          const candidate = target;
          const clickable =
            (typeof candidate.click === "function" && candidate) ||
            candidate.querySelector(
              'button, [role="button"], a, input[type="submit"], input[type="button"]',
            );

          if (clickable && typeof clickable.click === "function") {
            clickable.click();
            clicked = true;
          }
        }
        return { clicked, matchCount: matches.length, allIdsSample: all.slice(0, 50).map((el) => el.getAttribute("data-test-id")) };
      };

      // Let Vue/vee-validate finish re-rendering after autofill before clicking "pokracovat".
      const clickResultPromise = handledAutofill
        ? Promise.resolve().then(
            () =>
              new Promise((resolve) => {
                requestAnimationFrame(() => {
                  requestAnimationFrame(() => resolve(doActionClick("deferred-raf2")));
                });
              }),
          )
        : Promise.resolve(doActionClick("immediate"));

      // After the click, retry autofill for the next step in case navigation landed on a new URL.
      const nextStepIndex = stepIndex + 1;
      const nextStep = Array.isArray(scenario) && nextStepIndex >= 0 && nextStepIndex < scenario.length
        ? scenario[nextStepIndex]
        : null;
      if (isLoginStep(nextStep)) {
        setPendingLoginAutofill(scenario, nextStepIndex);
      }
      setTimeout(() => {
        Promise.resolve(autofillScenarioForCurrentUrl(scenario, nextStepIndex)).catch(() => {
          // ignore delayed autofill errors
        });
      }, 800);

      clickResultPromise.then((clickResult) => {
        sendResponse &&
          sendResponse({
            ok: true,
            found: clickResult.matchCount > 0,
            clicked: !!clickResult.clicked,
            autofilled: handledAutofill,
            mapMissing,
            matchCount: clickResult.matchCount,
            allIdsSample: clickResult.allIdsSample,
          });
      });
    });
  } catch (e) {
    console.error("ALF content script – chyba pri spracovaní scenára:", e);
    sendResponse && sendResponse({ ok: false, error: String(e) });
  }

  // keep channel open only synchronously
  return true;
});

runPendingLoginAutofillOnLoad();

let __alfHighlightObserver = null;
let __alfHighlightReapplyTimer = null;
const __ALF_LABEL_POSITIONS = ["top-left", "top-right", "bottom-left", "bottom-right"];
let __alfTestLabelPosition = "top-left";
let __alfTestMultiColor = false;
let __alfTestFilterMatchers = [];
let __alfShowDti = false;
let __alfShowBlocks = true;
// ACE taxonómia: ace- = atóm, acm- = molekula, aco- = organizmus, act- =
// šablóna, acp- = stránka - každá úroveň má vlastný nezávislý prepínač.
let __alfShowAtoms = false;
let __alfShowMolecules = false;
let __alfShowOrganisms = false;
let __alfShowTemplates = false;
let __alfShowPages = false;

function __alfUpdateHighlightState() {
  if (
    __alfShowDti ||
    __alfShowBlocks ||
    __alfShowAtoms ||
    __alfShowMolecules ||
    __alfShowOrganisms ||
    __alfShowTemplates ||
    __alfShowPages
  ) {
    __alfEnableHighlight();
  } else {
    __alfDisableHighlight();
  }
}

// DTI filter: when non-empty, only data-test-ids matching one of the terms are highlighted.
function __alfBuildFilterMatcher(term) {
  const raw = String(term == null ? "" : term).trim();
  if (!raw) return null;

  if (raw.includes("*")) {
    const regexSource = raw
      .split("*")
      .map((part) => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
      .join(".*");
    const regex = new RegExp(`^${regexSource}$`, "i");
    return (value) => regex.test(String(value == null ? "" : value));
  }

  const needle = raw.toLowerCase();
  return (value) => String(value == null ? "" : value).toLowerCase().includes(needle);
}

function __alfMatchesTestFilter(dataTestId) {
  if (!__alfTestFilterMatchers.length) return true;
  return __alfTestFilterMatchers.some((matcher) => matcher(dataTestId));
}

function __alfSetTestFilterTerms(rawTerms) {
  const terms = Array.isArray(rawTerms) ? rawTerms : [];
  __alfTestFilterMatchers = terms.map(__alfBuildFilterMatcher).filter(Boolean);
}

// 10 distinguishable colors cycled in order so dense DTI (e.g. sidebar menu) are not one red blob.
const __ALF_TEST_MULTI_COLORS = [
  "#ff3b30", // red
  "#ff9500", // orange
  "#ffcc00", // yellow
  "#34c759", // green
  "#00c7be", // teal
  "#30b0c7", // cyan
  "#007aff", // blue
  "#5856d6", // indigo
  "#af52de", // purple
  "#ff2d55", // pink
];

// APS (data-aps) je samostatná kategória zvýraznenia, nezávislá od TEST/BLOCK.
const __ALF_APS_COLOR = "#3b8830";

function __alfTestColorClass(index) {
  return `__qa-test-color-${index % __ALF_TEST_MULTI_COLORS.length}`;
}

// Vyberie čitateľnejšiu farbu textu (biela/tmavá) podľa jasu pozadia (YIQ) –
// napr. žltá potrebuje tmavý text, kým červená/modrá biely.
function __alfContrastTextColor(hex) {
  const clean = String(hex || "").replace("#", "");
  if (clean.length !== 6) return "white";
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 150 ? "#1c1c1e" : "white";
}

function __alfRemoveHighlight() {
  document.getElementById("__qa-highlight-style")?.remove();
  document.querySelectorAll(".__qa-label").forEach((el) => el.remove());
  document.querySelectorAll(".__qa-box").forEach((el) => el.remove());
  const colorClasses = __ALF_TEST_MULTI_COLORS.map((_, i) => __alfTestColorClass(i));
  document
    .querySelectorAll(".__qa-test-highlight, .__qa-block-highlight")
    .forEach((el) => {
      el.classList.remove(
        "__qa-test-highlight",
        "__qa-block-highlight",
        "__qa-block-header",
        "__qa-block-main",
        "__qa-block-footer",
        "__qa-block-sidebar",
        "__qa-block-other",
        ...colorClasses,
      );
      // Odstráni inline outline nastavený __alfOwnerBlockColor pre DTI vo
      // vnútri ne-main blokov (viď __alfApplyHighlight).
      el.style.removeProperty("outline");
    });
  document.querySelectorAll(".__qa-aps-highlight").forEach((el) => {
    el.classList.remove("__qa-aps-highlight");
    el.style.removeProperty("outline");
  });
}

function __alfBlockRegion(el) {
  if (el.closest("header")) return "header";
  if (el.closest("footer")) return "footer";
  if (el.closest("main")) return "main";
  return "other";
}

const __ALF_BLOCK_COLORS = {
  header: "#af52de",
  main: "#007aff",
  footer: "#ff9500",
  sidebar: "#34c759",
  other: "#5ac8fa",
};

// Replaced elements (select, input, img, ...) render no children, so the label is attached to document.body and positioned absolutely.
function __alfCreateHighlightLabel(element, text, value, color, position, inside) {
  const label = document.createElement("div");
  label.className = "__qa-label";
  label.textContent = `${text}: ${value}`;
  label.dataset.alfAnchor = __ALF_LABEL_POSITIONS.includes(position) ? position : "bottom-right";
  if (inside) label.dataset.alfInside = "true";

  Object.assign(label.style, {
    position: "absolute",
    background: color,
    color: __alfContrastTextColor(color),
    border: "1px solid white",
    borderRadius: "4px",
    padding: "2px 6px",
    fontFamily: "monospace",
    fontSize: "11px",
    fontWeight: "bold",
    whiteSpace: "nowrap",
    zIndex: "2147483000",
    cursor: "pointer",
    userSelect: "text",
    pointerEvents: "auto",
    boxShadow: "0 1px 4px rgba(0,0,0,.4)",
  });

  // On hover bring the label to the top (max z-index) among overlapping labels.
  label.addEventListener("mouseenter", () => {
    label.style.zIndex = "2147483647";
  });
  label.addEventListener("mouseleave", () => {
    label.style.zIndex = "2147483000";
  });

  label.title = "Click to copy";
  label.addEventListener("click", async (e) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(value);
      const originalText = label.textContent;
      const originalColor = label.style.background;
      label.textContent = "✅ Copied!";
      label.style.background = "#28a745";
      setTimeout(() => {
        label.textContent = originalText;
        label.style.background = originalColor;
      }, 1500);
    } catch (err) {
      console.error("Clipboard error:", err);
    }
  });

  label.__alfTargetElement = element;
  document.body.appendChild(label);
  __alfPositionLabel(label, element, position, inside);
}

// "inside": the label stays pinned to the element's inner edge so it cannot enlarge document.scrollHeight (BLOCK labels at the page bottom).
// display:contents wrappers have an empty rect, so fall back to the union of their children's rects.
function __alfEffectiveRect(el) {
  const rect = el.getBoundingClientRect();
  if (rect.width > 0 || rect.height > 0) return rect;
  if (window.getComputedStyle(el).display !== "contents") return rect;

  let left = Infinity;
  let top = Infinity;
  let right = -Infinity;
  let bottom = -Infinity;
  let found = false;
  Array.prototype.forEach.call(el.children, (child) => {
    const childRect = child.getBoundingClientRect();
    if (childRect.width === 0 && childRect.height === 0) return;
    found = true;
    // getBoundingClientRect() excludes margin; add the child's computed margin so the frame covers its visual space.
    const childStyle = window.getComputedStyle(child);
    const marginTop = parseFloat(childStyle.marginTop) || 0;
    const marginRight = parseFloat(childStyle.marginRight) || 0;
    const marginBottom = parseFloat(childStyle.marginBottom) || 0;
    const marginLeft = parseFloat(childStyle.marginLeft) || 0;
    left = Math.min(left, childRect.left - marginLeft);
    top = Math.min(top, childRect.top - marginTop);
    right = Math.max(right, childRect.right + marginRight);
    bottom = Math.max(bottom, childRect.bottom + marginBottom);
  });

  if (!found) return rect;
  return {
    left,
    top,
    right,
    bottom,
    width: right - left,
    height: bottom - top,
    x: left,
    y: top,
  };
}

function __alfPositionLabel(label, element, position, inside) {
  const rect = __alfEffectiveRect(element);
  const scrollX = window.scrollX || window.pageXOffset || 0;
  const scrollY = window.scrollY || window.pageYOffset || 0;
  const pos = __ALF_LABEL_POSITIONS.includes(position) ? position : "bottom-right";
  const isTop = pos === "top-left" || pos === "top-right";
  const isRight = pos === "top-right" || pos === "bottom-right";

  label.style.left = `${(isRight ? rect.right : rect.left) + scrollX}px`;
  label.style.top = `${(isTop ? rect.top : rect.bottom) + scrollY}px`;

  // Roh, ku ktorému je label ukotvený, sa nesmie posunúť do stredu elementu –
  // preto translateX(-100%) len keď kotvíme na pravý okraj (rect.right).
  const parts = [];
  if (isRight) parts.push("translateX(-100%)");
  if (inside) {
    parts.push(isTop ? "translateY(2px)" : "translateY(-100%) translateY(-2px)");
  } else {
    parts.push(isTop ? "translateY(-100%) translateY(-2px)" : "translateY(2px)");
  }
  const baseTransform = parts.join(" ");

  // Keep the clean transform so __alfDeclutterLabels can reset it before re-measuring.
  label.dataset.alfBaseTransform = baseTransform;
  label.style.transform = baseTransform;
  __alfClampLabelToViewport(label);
}

// display:contents elements have no box, so an outline renders nothing; draw a separate absolutely positioned frame over their effective rect.
function __alfCreateHighlightBox(element, color, borderStyle) {
  const box = document.createElement("div");
  box.className = "__qa-box";
  box.style.position = "absolute";
  box.style.border = `3px ${borderStyle || "solid"} ${color}`;
  box.style.zIndex = "2147482999";
  box.style.pointerEvents = "none";
  box.style.boxSizing = "border-box";
  box.__alfTargetElement = element;
  document.body.appendChild(box);
  __alfPositionHighlightBox(box, element);
}

function __alfPositionHighlightBox(box, element) {
  const rect = __alfEffectiveRect(element);
  const scrollX = window.scrollX || window.pageXOffset || 0;
  const scrollY = window.scrollY || window.pageYOffset || 0;
  box.style.left = `${rect.left + scrollX}px`;
  box.style.top = `${rect.top + scrollY}px`;
  box.style.width = `${rect.width}px`;
  box.style.height = `${rect.height}px`;
}

function __alfRepositionHighlightBoxes() {
  document.querySelectorAll(".__qa-box").forEach((box) => {
    const element = box.__alfTargetElement;
    if (element && document.contains(element)) {
      __alfPositionHighlightBox(box, element);
    }
  });
}

// Labels of elements at the page edge are pushed back inside the viewport after measuring their final position.
function __alfClampLabelToViewport(label) {
  const margin = 2;
  const rect = label.getBoundingClientRect();
  const vw = document.documentElement.clientWidth || window.innerWidth;
  const vh = document.documentElement.clientHeight || window.innerHeight;

  let dx = 0;
  let dy = 0;
  if (rect.left < margin) dx = margin - rect.left;
  else if (rect.right > vw - margin) dx = (vw - margin) - rect.right;
  if (rect.top < margin) dy = margin - rect.top;
  else if (rect.bottom > vh - margin) dy = (vh - margin) - rect.bottom;

  if (dx === 0 && dy === 0) return;
  const left = parseFloat(label.style.left) || 0;
  const top = parseFloat(label.style.top) || 0;
  label.style.left = `${left + dx}px`;
  label.style.top = `${top + dy}px`;
}

// Nested/adjacent elements have near-identical rects; spread their labels apart until they stop overlapping.
function __alfDeclutterLabels() {
  const labels = Array.prototype.slice.call(document.querySelectorAll(".__qa-label"));
  if (!labels.length) return;

  labels.forEach((label) => {
    label.style.transform = label.dataset.alfBaseTransform || label.style.transform;
  });

  const GAP = 2;
  const items = labels
    .map((label) => {
      const rect = label.getBoundingClientRect();
      return { label, top: rect.top, left: rect.left, right: rect.right, bottom: rect.bottom };
    })
    // Stabilné poradie zhora nadol, zľava doprava – horný/ľavší label ostáva na mieste.
    .sort((a, b) => a.top - b.top || a.left - b.left);

  const placed = [];
  items.forEach((item) => {
    let dy = 0;
    let guard = 0;
    let moved = true;
    while (moved && guard < 100) {
      moved = false;
      guard += 1;
      for (const p of placed) {
        const overlapsX = item.left < p.right && item.right > p.left;
        const overlapsY = item.top + dy < p.bottom && item.bottom + dy > p.top;
        if (overlapsX && overlapsY) {
          dy = p.bottom - item.top + GAP;
          moved = true;
        }
      }
    }

    if (dy !== 0) {
      const base = item.label.dataset.alfBaseTransform || "";
      item.label.style.transform = `${base} translateY(${dy}px)`;
    }
    __alfClampLabelToViewport(item.label);

    placed.push({ top: item.top + dy, left: item.left, right: item.right, bottom: item.bottom + dy });
  });
}

let __alfDeclutterRaf = null;
function __alfScheduleDeclutter() {
  if (__alfDeclutterRaf != null) return;
  __alfDeclutterRaf = requestAnimationFrame(() => {
    __alfDeclutterRaf = null;
    __alfDeclutterLabels();
  });
}

function __alfRepositionLabels() {
  document.querySelectorAll(".__qa-label").forEach((label) => {
    const element = label.__alfTargetElement;
    if (element && document.contains(element)) {
      __alfPositionLabel(label, element, label.dataset.alfAnchor, label.dataset.alfInside === "true");
    }
  });
  __alfRepositionHighlightBoxes();
  __alfScheduleDeclutter();
}

// Collapsed components (e.g. sidebar SubMenu) may only set height:0 + overflow:hidden on the wrapper while children keep a normal style,
// so alfIsVisible() says visible; walk up and check the element is not clipped by an overflow ancestor.
function __alfIsClippedByAncestor(el) {
  const rect = __alfEffectiveRect(el);
  let node = el.parentElement;

  while (node && node !== document.documentElement) {
    const style = window.getComputedStyle(node);
    const clipsX = style.overflowX === "hidden" || style.overflowX === "clip" || style.overflowX === "scroll" || style.overflowX === "auto";
    const clipsY = style.overflowY === "hidden" || style.overflowY === "clip" || style.overflowY === "scroll" || style.overflowY === "auto";

    if (clipsX || clipsY) {
      const ancestorRect = node.getBoundingClientRect();
      if (ancestorRect.width <= 0 || ancestorRect.height <= 0) return true;

      const intersects =
        rect.left < ancestorRect.right &&
        rect.right > ancestorRect.left &&
        rect.top < ancestorRect.bottom &&
        rect.bottom > ancestorRect.top;
      if (!intersects) return true;
    }

    node = node.parentElement;
  }

  return false;
}

// With DBI shown only DTI inside "main" stand out; DTI in other blocks get their block's color.
function __alfOwnerBlockColor(el) {
  if (!__alfShowBlocks) return null;
  const blockEl = el.closest("[data-block-id]");
  if (!blockEl) return null;
  const dbi = String(blockEl.getAttribute("data-block-id") || "").trim().toLowerCase();
  if (dbi === "main") return null;
  return __ALF_BLOCK_COLORS[__alfBlockRegion(blockEl)];
}

function __alfIsHighlightable(el) {
  const baseVisible = typeof alfIsVisible === "function" ? alfIsVisible(el) : true;
  if (!baseVisible) return false;
  return !__alfIsClippedByAncestor(el);
}

function __alfApplyHighlight() {
  __alfRemoveHighlight();

  const style = document.createElement("style");
  style.id = "__qa-highlight-style";
  style.textContent = `
    .__qa-test-highlight { outline: 3px solid #ff3b30 !important; }
    ${__ALF_TEST_MULTI_COLORS.map((c, i) => `.${__alfTestColorClass(i)} { outline: 3px solid ${c} !important; }`).join("\n    ")}
    .__qa-block-header { outline: 3px solid ${__ALF_BLOCK_COLORS.header} !important; }
    .__qa-block-main { outline: 3px solid ${__ALF_BLOCK_COLORS.main} !important; }
    .__qa-block-footer { outline: 3px solid ${__ALF_BLOCK_COLORS.footer} !important; }
    .__qa-block-sidebar { outline: 3px solid ${__ALF_BLOCK_COLORS.sidebar} !important; }
    .__qa-block-other { outline: 3px solid ${__ALF_BLOCK_COLORS.other} !important; }
    .__qa-aps-highlight { outline: 3px solid ${__ALF_APS_COLOR} !important; }
  `;
  document.head.appendChild(style);

  // Hidden elements (incl. clipped by overflow:hidden) are not highlighted; with a DTI filter only matching ones are.
  const testElements = __alfShowDti
    ? Array.prototype.filter.call(
        document.querySelectorAll("[data-test-id]"),
        (el) => __alfIsHighlightable(el) && __alfMatchesTestFilter(el.getAttribute("data-test-id")),
      )
    : [];
  testElements.forEach((el, i) => {
    const isContentsEl = window.getComputedStyle(el).display === "contents";
    const ownerColor = __alfOwnerBlockColor(el);
    let color;
    if (ownerColor) {
      color = ownerColor;
      if (isContentsEl) {
        __alfCreateHighlightBox(el, color);
      } else {
        el.classList.add("__qa-test-highlight");
        el.style.setProperty("outline", `3px solid ${color}`, "important");
      }
    } else {
      color = __alfTestMultiColor ? __ALF_TEST_MULTI_COLORS[i % __ALF_TEST_MULTI_COLORS.length] : "#ff3b30";
      if (isContentsEl) {
        __alfCreateHighlightBox(el, color);
      } else {
        el.classList.add("__qa-test-highlight");
        if (__alfTestMultiColor) el.classList.add(__alfTestColorClass(i));
      }
    }
    __alfCreateHighlightLabel(el, "TEST", el.getAttribute("data-test-id"), color, __alfTestLabelPosition);
  });

  const blockElements = __alfShowBlocks
    ? Array.prototype.filter.call(
        document.querySelectorAll("[data-block-id], acs-main, acs-sidebar, [class*='acs-']"),
        __alfIsHighlightable,
      )
    : [];
  blockElements.forEach((el) => {
    const tag = el.tagName ? el.tagName.toLowerCase() : "";
    const region = tag.startsWith("acs-")
      ? tag.replace("acs-", "")
      : (el.getAttribute("data-block-id") || "main").toLowerCase();
    const color = __ALF_BLOCK_COLORS[region] || "#8a2be2";
    if (window.getComputedStyle(el).display === "contents") {
      __alfCreateHighlightBox(el, color);
    } else {
      el.classList.add("__qa-block-highlight", "__qa-block-" + region);
    }
    __alfCreateHighlightLabel(el, "SECTION", region, color, "bottom-right", true);
  });

  const __alfApsLevelFor = (tag) => {
    if (tag.startsWith("ace-")) return "atom";
    if (tag.startsWith("acm-")) return "molecule";
    if (tag.startsWith("aco-")) return "organism";
    if (tag.startsWith("act-")) return "template";
    if (tag.startsWith("acp-")) return "page";
    return null;
  };
  // The ACE taxonomy stays in one green family, the shade varies by level.
  const __ALF_APS_LEVEL_COLORS = {
    atom: "#22c55e",
    molecule: "#86efac",
    organism: "#166534",
    template: "#14532d",
    page: "#052e16",
  };
  const __ALF_APS_LEVEL_BORDER_STYLE = {
    atom: "solid",
    molecule: "dotted",
    organism: "solid",
    template: "dashed",
    page: "double",
  };
  const __ALF_APS_LEVEL_LABELS = {
    atom: "ACE",
    molecule: "ACM",
    organism: "ACO",
    template: "ACT",
    page: "ACP",
  };
  const anyApsLevelOn =
    __alfShowAtoms || __alfShowMolecules || __alfShowOrganisms || __alfShowTemplates || __alfShowPages;
  const apsElements = anyApsLevelOn
    ? Array.prototype.filter.call(
        typeof __apsScanElements === "function" ? __apsScanElements() : Array.prototype.filter.call(document.querySelectorAll("*"), (el) => {
          const tag = el.tagName ? el.tagName.toLowerCase() : "";
          return tag.startsWith("ace-") || tag.startsWith("acm-") || tag.startsWith("aco-") || tag.startsWith("act-") || tag.startsWith("acp-");
        }),
        (el) => {
          const tag = el.tagName ? el.tagName.toLowerCase() : "";
          const level = __alfApsLevelFor(tag);
          if (level === "atom" && !__alfShowAtoms) return false;
          if (level === "molecule" && !__alfShowMolecules) return false;
          if (level === "organism" && !__alfShowOrganisms) return false;
          if (level === "template" && !__alfShowTemplates) return false;
          if (level === "page" && !__alfShowPages) return false;
          if (!level) return false;
          return __alfIsHighlightable(el);
        },
      )
    : [];
  apsElements.forEach((el) => {
    const { name } = typeof __apsParseElement === "function" ? __apsParseElement(el) : { name: el.tagName.toLowerCase() };
    const tag = el.tagName ? el.tagName.toLowerCase() : "";
    const level = __alfApsLevelFor(tag) || "atom";
    const color = __ALF_APS_LEVEL_COLORS[level];
    const borderStyle = __ALF_APS_LEVEL_BORDER_STYLE[level] || "solid";
    if (window.getComputedStyle(el).display === "contents") {
      __alfCreateHighlightBox(el, color, borderStyle);
    } else {
      el.classList.add("__qa-aps-highlight");
      el.style.setProperty("outline", `3px ${borderStyle} ${color}`, "important");
    }
    __alfCreateHighlightLabel(el, __ALF_APS_LEVEL_LABELS[level], name, color, "bottom-right", true);
  });

  __alfDeclutterLabels();

  const filterNote = __alfTestFilterMatchers.length ? `, filter aktívny (${__alfTestFilterMatchers.length} termínov)` : "";
  console.log(
    `✅ Highlighted ${testElements.length} data-test-id elements, ${blockElements.length} data-block-id elements and ${apsElements.length} data-aps elements (skryté sa preskočili${filterNote})`,
  );
}

function __alfObserveDom() {
  if (!document.body) return;
  // attributeFilter style/class also catches collapse components that toggle height/class instead of child nodes.
  __alfHighlightObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["style", "class", "hidden", "aria-hidden", "aria-expanded"],
  });
}

// Shared debounced re-apply for MutationObserver, click and scroll.
function __alfScheduleReapply() {
  clearTimeout(__alfHighlightReapplyTimer);
  __alfHighlightReapplyTimer = setTimeout(() => {
    // Observer odpojíme počas prekreslenia, aby naše vlastné labely nespustili ďalšiu slučku.
    if (__alfHighlightObserver) __alfHighlightObserver.disconnect();
    __alfApplyHighlight();
    if (__alfHighlightObserver) __alfObserveDom();
  }, 400);
}

function __alfOnScroll() {
  __alfRepositionLabels();
  // A scrollable menu can reveal/hide data-test-ids, so re-evaluate visibility fully, not just reposition.
  __alfScheduleReapply();
}

function __alfEnableHighlight() {
  __alfApplyHighlight();
  window.addEventListener("scroll", __alfOnScroll, true);
  window.addEventListener("resize", __alfRepositionLabels);
  document.addEventListener("click", __alfScheduleReapply, true);
  document.addEventListener("keyup", __alfScheduleReapply, true);
  if (__alfHighlightObserver) return;
  __alfHighlightObserver = new MutationObserver(__alfScheduleReapply);
  __alfObserveDom();
}

function __alfDisableHighlight() {
  if (__alfHighlightObserver) {
    __alfHighlightObserver.disconnect();
    __alfHighlightObserver = null;
  }
  clearTimeout(__alfHighlightReapplyTimer);
  window.removeEventListener("scroll", __alfOnScroll, true);
  window.removeEventListener("resize", __alfRepositionLabels);
  document.removeEventListener("click", __alfScheduleReapply, true);
  document.removeEventListener("keyup", __alfScheduleReapply, true);
  __alfRemoveHighlight();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;
  if (message.type === "ALF_TOGGLE_HIGHLIGHT") {
    try {
      __alfShowDti = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – highlight error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_TEST_LABEL_POSITION") {
    try {
      __alfTestLabelPosition = __ALF_LABEL_POSITIONS.includes(message.position) ? message.position : "top-left";
      if (__alfHighlightObserver) __alfApplyHighlight();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – test label position error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_TEST_MULTICOLOR") {
    try {
      __alfTestMultiColor = !!message.enabled;
      if (__alfHighlightObserver) __alfApplyHighlight();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – test multicolor error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_BLOCKS") {
    try {
      __alfShowBlocks = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show blocks error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_ATOMS") {
    try {
      __alfShowAtoms = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show atoms error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_MOLECULES") {
    try {
      __alfShowMolecules = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show molecules error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_ORGANISMS") {
    try {
      __alfShowOrganisms = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show organisms error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_TEMPLATES") {
    try {
      __alfShowTemplates = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show templates error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_SHOW_PAGES") {
    try {
      __alfShowPages = !!message.enabled;
      __alfUpdateHighlightState();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – show pages error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
  if (message.type === "ALF_SET_TEST_FILTER") {
    try {
      __alfSetTestFilterTerms(message.terms);
      if (__alfHighlightObserver) __alfApplyHighlight();
      sendResponse && sendResponse({ ok: true });
    } catch (e) {
      console.error("ALF content script – test filter error:", e);
      sendResponse && sendResponse({ ok: false, error: String(e) });
    }
    return;
  }
});

try {
  chrome.storage?.sync?.get?.(["ALF_HIGHLIGHT", "ALF_TEST_LABEL_POSITION", "ALF_TEST_MULTICOLOR", "ALF_TEST_FILTER", "ALF_SHOW_BLOCKS", "ALF_SHOW_APS", "ALF_SHOW_ATOMS", "ALF_SHOW_MOLECULES", "ALF_SHOW_ORGANISMS", "ALF_SHOW_TEMPLATES", "ALF_SHOW_PAGES"], (res) => {
    if (chrome.runtime.lastError) return;
    __alfTestLabelPosition = __ALF_LABEL_POSITIONS.includes(res && res.ALF_TEST_LABEL_POSITION) ? res.ALF_TEST_LABEL_POSITION : "top-left";
    __alfTestMultiColor = !!(res && (res.ALF_TEST_MULTICOLOR === true || res.ALF_TEST_MULTICOLOR === "true"));
    __alfShowBlocks = !(res && (res.ALF_SHOW_BLOCKS === false || res.ALF_SHOW_BLOCKS === "false"));
    // ALF_SHOW_APS is a legacy key: used as the initial atoms value when ALF_SHOW_ATOMS is not stored yet.
    const legacyShowAps = !!(res && (res.ALF_SHOW_APS === true || res.ALF_SHOW_APS === "true"));
    __alfShowAtoms = res && res.ALF_SHOW_ATOMS !== undefined
      ? !!(res.ALF_SHOW_ATOMS === true || res.ALF_SHOW_ATOMS === "true")
      : legacyShowAps;
    __alfShowMolecules = !!(res && (res.ALF_SHOW_MOLECULES === true || res.ALF_SHOW_MOLECULES === "true"));
    __alfShowOrganisms = !!(res && (res.ALF_SHOW_ORGANISMS === true || res.ALF_SHOW_ORGANISMS === "true"));
    __alfShowTemplates = !!(res && (res.ALF_SHOW_TEMPLATES === true || res.ALF_SHOW_TEMPLATES === "true"));
    __alfShowPages = !!(res && (res.ALF_SHOW_PAGES === true || res.ALF_SHOW_PAGES === "true"));
    __alfSetTestFilterTerms(res && res.ALF_TEST_FILTER);
    __alfShowDti = !!(res && (res.ALF_HIGHLIGHT === true || res.ALF_HIGHLIGHT === "true"));
    __alfUpdateHighlightState();
  });
} catch (e) {
  console.warn("ALF content script – nepodarilo sa načítať highlight nastavenie:", e);
}

