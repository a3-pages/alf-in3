window.addEventListener("error", (event) => {
  alfLog("error", "DevTools Panel Error:", event.message, event.filename, event.lineno);
});
window.addEventListener("unhandledrejection", (event) => {
  alfLog("error", "DevTools Unhandled Promise:", event.reason && event.reason.message ? event.reason.message : event.reason);
});

async function init() {
  initCustomDropdowns();
  const apiSelect = $("apiSelect");

  try {
    const versionEl = $("alfVersion");
    if (versionEl && chrome.runtime && chrome.runtime.getManifest) {
      const manifest = chrome.runtime.getManifest();
      if (manifest && manifest.version) {
        versionEl.textContent = `v${manifest.version}`;
      }
    }
  } catch {
    // verzia je len kozmetická informácia
  }

  currentBaseUrl = (await loadStoredUrl()) || "https://a3.ugkk.dev/";
  await loadProjectsIntoSelect();
  await loadAmsInfoIntoUi();
  await loadPresetsIntoSelect();
  await loadSuitesIntoSelect();
  await loadScenariosIntoSelect();

  const presetSelect = $("presetSelect");
  if (presetSelect) {
    presetSelect.addEventListener("change", async () => {
      updatePresetDescription();
      await saveStoredValue(STORAGE_KEY_PRESET, presetSelect.value);
      await loadScenariosIntoSelect();
      const selectedScenario = apiSelect && apiSelect.value ? String(apiSelect.value).trim() : "";
      if (!selectedScenario) {
        const presetId = presetSelect.value;
        if (presetId && currentPresetsMap.has(presetId)) {
          const preset = currentPresetsMap.get(presetId);
          // Host of the project's client, else of the preset's first client.
          const nestedUrl = resolveClientHost(preset, currentProject);
          const firstHost = preset.env ? preset.env.trim() : "";
          const newUrl = nestedUrl || (firstHost ? (firstHost.startsWith("http") ? firstHost : `https://${firstHost}`) : "");
          if (newUrl) {
            try {
              const inspected = chrome.devtools?.inspectedWindow;
              const tabId = inspected?.tabId;
              if (tabId != null) chrome.tabs.update(tabId, { url: newUrl });
            } catch {}
          }
        }
        return;
      }
      await loadScenario();
    });
  }

  const projectSelect = $("projectSelect");
  if (projectSelect) {
    projectSelect.addEventListener("change", async () => {
      currentProject = projectSelect.value;
      await saveProject(currentProject);

      lastScenario = null;
      lastScenarioIndex = -1;
      lastScenarioFilePath = null;
      lastAssertResultsByStep.clear();
      lastRunStateByStep.clear();
      setPrimaryButtonMode(STEP_MODE_ACTION);

      const apiResult = $("apiResult");
      if (apiResult) apiResult.textContent = "";
      renderAssertionResults(null);

      try {
        const inspected = chrome.devtools?.inspectedWindow;
        const tabId = inspected?.tabId;
        if (tabId != null) chrome.action.setBadgeText({ text: "", tabId });
        const stepBadge = $("stepBadge");
        if (stepBadge) stepBadge.textContent = "0/0";
      } catch (e) {
        alfLog("warn", "nepodarilo sa vyčistiť badge:", e && e.message ? e.message : e);
      }

      await loadPresetsIntoSelect();
      await loadSuitesIntoSelect();
      await loadScenariosIntoSelect();
      updateActionButtonState();
    });
  }

  const refreshPresetsBtn = $("refreshPresetsBtn");
  if (refreshPresetsBtn) {
    refreshPresetsBtn.addEventListener("click", async () => {
      await loadPresetsIntoSelect();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  // alf-nod3 is a hash-routed SPA; #<tab>?client=<project>&id=<id> is the format the app builds itself on list clicks.
  function openAlfNodeTab(tab, id, whatLabel) {
    if (!id) {
      alfLog("warn", `otvorenie node zlyhalo: nie je vybraný ${whatLabel}.`);
      return;
    }
    const base = currentBaseUrl ? currentBaseUrl.trim().replace(/\/+$/, "") : "";
    if (!base) {
      alfLog("warn", "otvorenie node zlyhalo: nie je nastavená A3 URL (pozri Client).");
      return;
    }
    const qs = new URLSearchParams(currentProject ? { client: currentProject, id } : { id }).toString();
    window.open(`${base}/@/alf-nod3#${tab}?${qs}`, "_blank", "noopener");
  }

  const openPresetNodeBtn = $("openPresetNodeBtn");
  if (openPresetNodeBtn) {
    openPresetNodeBtn.addEventListener("click", () => {
      openAlfNodeTab("presets", presetSelect ? presetSelect.value : "", "preset");
    });
  }

  const suiteSelect = $("suiteSelect");
  if (suiteSelect) {
    suiteSelect.addEventListener("change", async () => {
      await saveStoredValue(STORAGE_KEY_SUITE, suiteSelect.value);
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const refreshSuitesBtn = $("refreshSuitesBtn");
  if (refreshSuitesBtn) {
    refreshSuitesBtn.addEventListener("click", async () => {
      await loadSuitesIntoSelect();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const openSuiteNodeBtn = $("openSuiteNodeBtn");
  if (openSuiteNodeBtn) {
    openSuiteNodeBtn.addEventListener("click", () => {
      openAlfNodeTab("suites", suiteSelect ? suiteSelect.value : "", "suite");
    });
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) {
    runScenarioStepBtn.disabled = true;
    setPrimaryButtonMode(STEP_MODE_ACTION);
    runScenarioStepBtn.addEventListener("click", () => {
      resumeAutoRun();
      runScenarioStep();
    });
  }

  const autoRunBtn = $("autoRunBtn");
  if (autoRunBtn) autoRunBtn.addEventListener("click", toggleAutoRun);

  const autoIntervalSelect = $("autoIntervalSelect");
  if (autoIntervalSelect) {
    autoIntervalSelect.addEventListener("change", () => {
      if (autoRunTimer !== null) startAutoRun();
    });
  }

  const prevScenarioStepBtn = $("prevScenarioStepBtn");
  if (prevScenarioStepBtn) {
    prevScenarioStepBtn.disabled = true;
    prevScenarioStepBtn.addEventListener("click", prevScenarioStep);
  }

  const resetScenarioBtn = $("resetScenarioBtn");
  if (resetScenarioBtn) {
    resetScenarioBtn.addEventListener("click", () => {
      stopAutoRun("vypnutý: Reset");
      resetScenario();
    });
  }

  const refreshScenariosBtn = $("refreshScenariosBtn");
  if (refreshScenariosBtn) {
    refreshScenariosBtn.addEventListener("click", async () => {
      await loadAmsInfoIntoUi();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const openFlowNodeBtn = $("openFlowNodeBtn");
  if (openFlowNodeBtn) {
    openFlowNodeBtn.addEventListener("click", () => {
      openAlfNodeTab("flows", apiSelect ? apiSelect.value : "", "flow");
    });
  }

  const logClearBtn = $("logClearBtn");
  if (logClearBtn) {
    logClearBtn.addEventListener("click", () => {
      const logArea = $("logArea");
      if (logArea) logArea.innerHTML = "";
    });
  }

  const highlightDtiCheckbox = $("highlightDtiCheckbox");
  if (highlightDtiCheckbox) {
    const storedHighlight = await loadStoredValue(STORAGE_KEY_HIGHLIGHT);
    highlightDtiCheckbox.checked = storedHighlight === true || storedHighlight === "true";
    if (highlightDtiCheckbox.checked) sendHighlightToggle(true);

    highlightDtiCheckbox.addEventListener("change", async () => {
      const enabled = highlightDtiCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_HIGHLIGHT, enabled);
      sendHighlightToggle(enabled);
      // Colour labels and DBI are companions of DTI highlighting — switch them together.
      for (const id of ["testMultiColorCheckbox", "showBlocksCheckbox"]) {
        const companion = $(id);
        if (companion && companion.checked !== enabled) {
          companion.checked = enabled;
          companion.dispatchEvent(new Event("change"));
        }
      }
    });
  }

  const testLabelPositionGroup = $("testLabelPositionGroup");
  if (testLabelPositionGroup) {
    const positionBtns = Array.prototype.slice.call(testLabelPositionGroup.querySelectorAll(".pos-btn"));
    const validPositions = positionBtns.map((btn) => btn.dataset.position);

    const applyActivePosition = (position) => {
      positionBtns.forEach((btn) => {
        const isActive = btn.dataset.position === position;
        btn.classList.toggle("active", isActive);
        btn.setAttribute("aria-pressed", String(isActive));
      });
    };

    const storedPosition = await loadStoredValue(STORAGE_KEY_TEST_LABEL_POSITION);
    const initialPosition = validPositions.includes(storedPosition) ? storedPosition : "top-left";
    applyActivePosition(initialPosition);
    sendTestLabelPosition(initialPosition);

    positionBtns.forEach((btn) => {
      btn.addEventListener("click", async () => {
        const position = btn.dataset.position;
        applyActivePosition(position);
        await saveStoredValue(STORAGE_KEY_TEST_LABEL_POSITION, position);
        sendTestLabelPosition(position);
      });
    });
  }

  const testMultiColorCheckbox = $("testMultiColorCheckbox");
  if (testMultiColorCheckbox) {
    const storedMultiColor = await loadStoredValue(STORAGE_KEY_TEST_MULTICOLOR);
    testMultiColorCheckbox.checked = storedMultiColor === true || storedMultiColor === "true";
    sendTestMultiColorToggle(testMultiColorCheckbox.checked);

    testMultiColorCheckbox.addEventListener("change", async () => {
      const enabled = testMultiColorCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_TEST_MULTICOLOR, enabled);
      sendTestMultiColorToggle(enabled);
    });
  }

  const showBlocksCheckbox = $("showBlocksCheckbox");
  if (showBlocksCheckbox) {
    const storedShowBlocks = await loadStoredValue(STORAGE_KEY_SHOW_BLOCKS);
    showBlocksCheckbox.checked = storedShowBlocks === true || storedShowBlocks === "true" || storedShowBlocks === undefined;
    sendShowBlocksToggle(showBlocksCheckbox.checked);

    showBlocksCheckbox.addEventListener("change", async () => {
      const enabled = showBlocksCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_SHOW_BLOCKS, enabled);
      sendShowBlocksToggle(enabled);
    });
  }

  const showAtomsCheckbox = $("showAtomsCheckbox");
  if (showAtomsCheckbox) {
    // ALF_SHOW_APS is a legacy key: used as the initial atoms value when ALF_SHOW_ATOMS is not stored yet.
    const storedShowAtoms = await loadStoredValue(STORAGE_KEY_SHOW_ATOMS);
    if (storedShowAtoms === undefined) {
      const legacyShowAps = await loadStoredValue(STORAGE_KEY_SHOW_APS);
      showAtomsCheckbox.checked = legacyShowAps === true || legacyShowAps === "true";
    } else {
      showAtomsCheckbox.checked = storedShowAtoms === true || storedShowAtoms === "true";
    }
    sendShowAtomsToggle(showAtomsCheckbox.checked);

    showAtomsCheckbox.addEventListener("change", async () => {
      const enabled = showAtomsCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_SHOW_ATOMS, enabled);
      sendShowAtomsToggle(enabled);
    });
  }

  const showMoleculesCheckbox = $("showMoleculesCheckbox");
  if (showMoleculesCheckbox) {
    const storedShowMolecules = await loadStoredValue(STORAGE_KEY_SHOW_MOLECULES);
    showMoleculesCheckbox.checked = storedShowMolecules === true || storedShowMolecules === "true";
    sendShowMoleculesToggle(showMoleculesCheckbox.checked);

    showMoleculesCheckbox.addEventListener("change", async () => {
      const enabled = showMoleculesCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_SHOW_MOLECULES, enabled);
      sendShowMoleculesToggle(enabled);
    });
  }

  const showOrganismsCheckbox = $("showOrganismsCheckbox");
  if (showOrganismsCheckbox) {
    const storedShowOrganisms = await loadStoredValue(STORAGE_KEY_SHOW_ORGANISMS);
    showOrganismsCheckbox.checked = storedShowOrganisms === true || storedShowOrganisms === "true";
    sendShowOrganismsToggle(showOrganismsCheckbox.checked);

    showOrganismsCheckbox.addEventListener("change", async () => {
      const enabled = showOrganismsCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_SHOW_ORGANISMS, enabled);
      sendShowOrganismsToggle(enabled);
    });
  }

  // Template/Page highlighting has no UI anymore — clear any previously stored "on" state.
  await saveStoredValue(STORAGE_KEY_SHOW_TEMPLATES, false);
  await saveStoredValue(STORAGE_KEY_SHOW_PAGES, false);
  sendShowTemplatesToggle(false);
  sendShowPagesToggle(false);

  const testFilterInput = $("testFilterInput");
  const testFilterChips = $("testFilterChips");
  if (testFilterInput && testFilterChips) {
    const storedFilter = await loadStoredValue(STORAGE_KEY_TEST_FILTER);
    let filterTerms = Array.isArray(storedFilter)
      ? storedFilter.filter((t) => typeof t === "string" && t.trim() !== "")
      : [];

    const renderFilterChips = () => {
      testFilterChips.innerHTML = "";
      filterTerms.forEach((term, index) => {
        const chip = document.createElement("span");
        chip.className = "filter-chip";

        const label = document.createElement("span");
        label.textContent = term;
        chip.appendChild(label);

        const removeBtn = document.createElement("button");
        removeBtn.type = "button";
        removeBtn.className = "filter-chip-remove";
        removeBtn.textContent = "✕";
        removeBtn.setAttribute("aria-label", `Odstrániť filter "${term}"`);
        removeBtn.addEventListener("click", async () => {
          filterTerms.splice(index, 1);
          renderFilterChips();
          await saveStoredValue(STORAGE_KEY_TEST_FILTER, filterTerms);
          sendTestFilter(filterTerms);
        });
        chip.appendChild(removeBtn);

        testFilterChips.appendChild(chip);
      });
    };

    renderFilterChips();
    sendTestFilter(filterTerms);

    testFilterInput.addEventListener("keydown", async (e) => {
      if (e.key !== "Enter") return;
      e.preventDefault();
      const value = testFilterInput.value.trim();
      if (!value) return;
      if (!filterTerms.includes(value)) {
        filterTerms.push(value);
        renderFilterChips();
        await saveStoredValue(STORAGE_KEY_TEST_FILTER, filterTerms);
        sendTestFilter(filterTerms);
      }
      testFilterInput.value = "";
    });
  }

  apiSelect.addEventListener("change", async () => {
    updateScenarioDescription();
    await saveStoredValue(STORAGE_KEY_FLOW, apiSelect.value);
    const apiResult = $("apiResult");

    apiResult.textContent = "";
    renderAssertionResults(null);
    lastScenario = null;
    lastScenarioIndex = -1;
    lastScenarioFilePath = null;
    lastAssertResultsByStep.clear();
    lastRunStateByStep.clear();
    setPrimaryButtonMode(STEP_MODE_ACTION);

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        chrome.action.setBadgeText({ text: "", tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge) {
        stepBadge.textContent = "0/0";
      }
    } catch (e) {
      alfLog("warn", "nepodarilo sa vyčistiť badge:", e && e.message ? e.message : e);
    }

    loadScenario();
    updateActionButtonState();
  });
}

function sendHighlightToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_TOGGLE_HIGHLIGHT", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "highlight toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "highlight toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendTestLabelPosition(position) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_TEST_LABEL_POSITION", position }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "test label position:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "test label position výnimka:", e && e.message ? e.message : e);
  }
}

function sendTestMultiColorToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_TEST_MULTICOLOR", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "test multicolor:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "test multicolor výnimka:", e && e.message ? e.message : e);
  }
}

function sendShowBlocksToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_SHOW_BLOCKS", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "show blocks toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "show blocks toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendShowAtomsToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_SHOW_ATOMS", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "show atoms toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "show atoms toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendShowMoleculesToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_SHOW_MOLECULES", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "show molecules toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "show molecules toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendShowOrganismsToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_SHOW_ORGANISMS", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "show organisms toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "show organisms toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendShowTemplatesToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_SHOW_TEMPLATES", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "show templates toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "show templates toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendShowPagesToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_SHOW_PAGES", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "show pages toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "show pages toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendTestFilter(terms) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_TEST_FILTER", terms }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "test filter:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "test filter výnimka:", e && e.message ? e.message : e);
  }
}

document.addEventListener("DOMContentLoaded", init);
