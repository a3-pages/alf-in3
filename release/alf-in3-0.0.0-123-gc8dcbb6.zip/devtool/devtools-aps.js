// APS scraper trigger: asks the content script to scan the page, then writes the base64 payload to the clipboard from the panel,
// which has focus right after the user's click (the content script's context may throw "Document is not focused").

function requestApsScrape(onDone) {
  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) return;

  chrome.tabs.sendMessage(tabId, { type: "ALF_SCRAPE_APS" }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "aps scrape:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      return;
    }
    if (!response || !response.ok) {
      alfLog("warn", "aps scrape failed:", response && response.error);
      return;
    }
    onDone(response);
  });
}

function scrapeAps() {
  requestApsScrape(async (response) => {
    const urlField = $("apsResultUrl");
    if (urlField) urlField.value = response.base64;

    try {
      await navigator.clipboard.writeText(response.base64);
      alfLog("info", `aps scrape: ${response.count} elementov skopírovaných do schránky (base64)`);
    } catch (e) {
      alfLog("warn", "aps scrape: zápis do schránky zlyhal:", e && e.message ? e.message : e);
    }
  });
}

// currentBaseUrl is the a3/arch-it3ct host serving /@/alf-engine and /@/aps, so it is reused here.
// "/+/" bypasses checkAccess (a3.public in arch-it3ct.yml), so edit/view work without login; the payload sits in the path (not after "#")
// so the server sees it and swapping "edit" -> "view" in the address bar gives a direct preview.
const APS_MAX_URL_BASE64_LENGTH = 6000;

function buildApsUrl(kind, base64) {
  const base = currentBaseUrl ? currentBaseUrl.trim().replace(/\/$/, "") : "";
  if (!base) {
    alfLog("warn", "aps otvorenie zlyhalo: nie je nastavená A3 URL (pozri Client).");
    return null;
  }
  if (kind === "edit") {
    return `${base}/+/acp/edit/${base64}`;
  }
  return null;
}

// A payload over APS_MAX_URL_BASE64_LENGTH is saved on the server (POST /+/acp/save), which returns a short id, like scheduleSaveShortUrl in arch-it3ct editor.js.
async function saveApsShortUrl(base, yaml) {
  const res = await fetch(`${base}/+/acp/save`, {
    method: "POST",
    headers: { "Content-Type": "text/yaml" },
    body: yaml
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const { editUrl } = await res.json();
  if (!editUrl) throw new Error("save: chýba editUrl v odpovedi");
  return `${base}${editUrl}`;
}

function openAps(kind) {
  requestApsScrape(async (response) => {
    const urlField = $("apsResultUrl");
    if (urlField) urlField.value = response.base64;

    const base = currentBaseUrl ? currentBaseUrl.trim().replace(/\/$/, "") : "";
    if (!base) {
      alfLog("warn", "aps otvorenie zlyhalo: nie je nastavená A3 URL.");
      return;
    }

    if (kind === "edit") {
      if (response.base64.length > APS_MAX_URL_BASE64_LENGTH) {
        try {
          const url = await saveApsShortUrl(base, response.yaml);
          window.open(url, "_blank", "noopener");
        } catch (e) {
          alfLog("error", `aps edit (save) zlyhalo: ${e.message}`);
          return;
        }
      } else {
        const url = buildApsUrl(kind, response.base64);
        if (url) window.open(url, "_blank", "noopener");
      }
    } else if (kind === "view") {
      try {
        const res = await fetch(`${base}/+/acp/view`, {
          method: "POST",
          headers: { "Content-Type": "text/yaml" },
          body: response.yaml
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        window.open(url, "_blank", "noopener");
      } catch (e) {
        alfLog("error", `aps view zlyhalo: ${e.message}`);
      }
    }
    alfLog("info", `aps ${kind}: otvorené s ${response.count} naskrapovanými elementmi`);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = $("scrapeApsBtn");
  if (btn) btn.addEventListener("click", scrapeAps);

  const editBtn = $("apsEditBtn");
  if (editBtn) editBtn.addEventListener("click", () => openAps("edit"));

  const viewBtn = $("apsViewBtn");
  if (viewBtn) viewBtn.addEventListener("click", () => openAps("view"));

  const urlField = $("apsResultUrl");
  if (urlField) {
    urlField.addEventListener("click", () => {
      urlField.select();
    });
  }
});
