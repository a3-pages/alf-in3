// APS scraper trigger: asks the content script (aps-scraper.js) to scan the
// inspected page for [data-aps] elements, then writes the resulting base64
// payload to the clipboard from here (the panel), not from the content
// script - the panel reliably has focus right after the user's own click,
// while the content script's message-response context might not, which can
// make navigator.clipboard.writeText throw "Document is not focused".

function scrapeAps() {
  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) return;

  chrome.tabs.sendMessage(tabId, { type: "ALF_SCRAPE_APS" }, async (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "aps scrape:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      return;
    }
    if (!response || !response.ok) {
      alfLog("warn", "aps scrape failed:", response && response.error);
      return;
    }

    const urlField = $("apsResultUrl");
    const url = `http://localhost:3003/aps-3dit/${response.base64}`;
    if (urlField) urlField.value = url;

    try {
      await navigator.clipboard.writeText(response.base64);
      alfLog("info", `aps scrape: ${response.count} elementov skopírovaných do schránky (base64)`);
    } catch (e) {
      alfLog("warn", "aps scrape: zápis do schránky zlyhal:", e && e.message ? e.message : e);
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = $("scrapeApsBtn");
  if (btn) btn.addEventListener("click", scrapeAps);

  const urlField = $("apsResultUrl");
  if (urlField) {
    urlField.addEventListener("click", () => {
      urlField.select();
    });
  }
});
