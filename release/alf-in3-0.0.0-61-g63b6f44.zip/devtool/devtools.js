async function init() {
  const apiSelect = $("apiSelect");

  try {
    const versionEl = $("alfVersion");
    if (versionEl && chrome.runtime && chrome.runtime.getManifest) {
      const manifest = chrome.runtime.getManifest();
      if (manifest && manifest.version) {
        versionEl.textContent = `v${manifest.version}`;
      }
    }
  } catch {
    // verzia je len kozmetická informácia
  }

  currentBaseUrl = (await loadStoredUrl()) || "https://a3.ugkk.dev/";
  await loadAmsInfoIntoUi();
  await loadPresetsIntoSelect();
  await loadSuitesIntoSelect();
  await loadScenariosIntoSelect();

  const presetSelect = $("presetSelect");
  if (presetSelect) {
    presetSelect.addEventListener("change", async () => {
      updatePresetDescription();
      await loadScenariosIntoSelect();
      const selectedScenario = apiSelect && apiSelect.value ? String(apiSelect.value).trim() : "";
      if (!selectedScenario) {
        const presetId = presetSelect.value;
        if (presetId && currentPresetsMap.has(presetId)) {
          const preset = currentPresetsMap.get(presetId);
          if (preset.env) {
            let newUrl = preset.env.trim();
            if (!newUrl.startsWith("http")) newUrl = "https://" + newUrl;
            try {
              const inspected = chrome.devtools?.inspectedWindow;
              const tabId = inspected?.tabId;
              if (tabId != null) chrome.tabs.update(tabId, { url: newUrl });
            } catch {}
          }
        }
        return;
      }
      await loadScenario();
    });
  }

  const refreshPresetsBtn = $("refreshPresetsBtn");
  if (refreshPresetsBtn) {
    refreshPresetsBtn.addEventListener("click", async () => {
      await loadPresetsIntoSelect();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const suiteSelect = $("suiteSelect");
  if (suiteSelect) {
    suiteSelect.addEventListener("change", async () => {
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const refreshSuitesBtn = $("refreshSuitesBtn");
  if (refreshSuitesBtn) {
    refreshSuitesBtn.addEventListener("click", async () => {
      await loadSuitesIntoSelect();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) {
    runScenarioStepBtn.disabled = true;
    setPrimaryButtonMode(STEP_MODE_ACTION);
    runScenarioStepBtn.addEventListener("click", runScenarioStep);
  }

  const resetScenarioBtn = $("resetScenarioBtn");
  if (resetScenarioBtn) {
    resetScenarioBtn.disabled = true;
    resetScenarioBtn.addEventListener("click", resetScenario);
  }

  const refreshScenariosBtn = $("refreshScenariosBtn");
  if (refreshScenariosBtn) {
    refreshScenariosBtn.addEventListener("click", async () => {
      await loadAmsInfoIntoUi();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const logClearBtn = $("logClearBtn");
  if (logClearBtn) {
    logClearBtn.addEventListener("click", () => {
      const logArea = $("logArea");
      if (logArea) logArea.innerHTML = "";
    });
  }

  apiSelect.addEventListener("change", () => {
    updateScenarioDescription();
    const apiResult = $("apiResult");

    apiResult.textContent = "";
    renderAssertionResults(null);
    lastScenario = null;
    lastScenarioIndex = -1;
    lastScenarioFilePath = null;
    lastAssertResultsByStep.clear();
    setPrimaryButtonMode(STEP_MODE_ACTION);

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        chrome.action.setBadgeText({ text: "", tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge) {
        stepBadge.textContent = "0/0";
      }
    } catch (e) {
      alfLog("warn", "ALF DevTools – nepodarilo sa vyčistiť badge:", e && e.message ? e.message : e);
    }

    loadScenario();
    updateActionButtonState();
  });
}

document.addEventListener("DOMContentLoaded", init);
