// APS scraper trigger: asks the content script (aps-scraper.js) to scan the
// inspected page for [data-aps] elements, then writes the resulting base64
// payload to the clipboard from here (the panel), not from the content
// script - the panel reliably has focus right after the user's own click,
// while the content script's message-response context might not, which can
// make navigator.clipboard.writeText throw "Document is not focused".

function requestApsScrape(onDone) {
  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) return;

  chrome.tabs.sendMessage(tabId, { type: "ALF_SCRAPE_APS" }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "aps scrape:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      return;
    }
    if (!response || !response.ok) {
      alfLog("warn", "aps scrape failed:", response && response.error);
      return;
    }
    onDone(response);
  });
}

function scrapeAps() {
  requestApsScrape(async (response) => {
    const urlField = $("apsResultUrl");
    if (urlField) urlField.value = response.base64;

    try {
      await navigator.clipboard.writeText(response.base64);
      alfLog("info", `aps scrape: ${response.count} elementov skopírovaných do schránky (base64)`);
    } catch (e) {
      alfLog("warn", "aps scrape: zápis do schránky zlyhal:", e && e.message ? e.message : e);
    }
  });
}

// Client (currentBaseUrl, viď devtools-state.js) je ten istý a3/arch-it3ct
// host, na ktorom beží /@/alf-engine aj /@/aps – preto ho vieme priamo
// znovupoužiť aj tu, bez ďalšieho nastavovania.
function buildApsUrl(kind, base64) {
  const base = currentBaseUrl ? currentBaseUrl.trim().replace(/\/$/, "") : "";
  if (!base) {
    alfLog("warn", "aps otvorenie zlyhalo: nie je nastavená A3 URL (pozri Client).");
    return null;
  }
  return `${base}/@/aps/${kind}/${base64}`;
}

function openAps(kind) {
  requestApsScrape((response) => {
    const urlField = $("apsResultUrl");
    if (urlField) urlField.value = response.base64;

    const url = buildApsUrl(kind, response.base64);
    if (!url) return;
    window.open(url, "_blank", "noopener");
    alfLog("info", `aps ${kind}: otvorené s ${response.count} naskrapovanými elementmi`);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = $("scrapeApsBtn");
  if (btn) btn.addEventListener("click", scrapeAps);

  const editBtn = $("apsEditBtn");
  if (editBtn) editBtn.addEventListener("click", () => openAps("edit"));

  const viewBtn = $("apsViewBtn");
  if (viewBtn) viewBtn.addEventListener("click", () => openAps("view"));

  const urlField = $("apsResultUrl");
  if (urlField) {
    urlField.addEventListener("click", () => {
      urlField.select();
    });
  }
});
