// Spustí sa v kontexte devtools_page a vytvorí vlastný panel ALF.
chrome.devtools.panels.create("ALF", "", "devtool/devtools-panel.html", function () {});

