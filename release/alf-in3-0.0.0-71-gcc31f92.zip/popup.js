const STORAGE_KEY_API_URL = "ALF_A3";
const DEFAULT_A3_URL = "https://a3.ugkk.dev/";

document.addEventListener("DOMContentLoaded", async () => {
  const versionEl = document.getElementById("version");
  const nameRowEl = document.getElementById("nameRow");
  const apiUrlInput = document.getElementById("apiUrl");
  const saveUrlBtn = document.getElementById("saveUrlBtn");

  try {
    const manifest = chrome.runtime.getManifest();
    if (versionEl) {
      versionEl.textContent = manifest.version || "neznáma";
    }
  } catch (e) {
    if (versionEl) {
      versionEl.textContent = "chyba pri čítaní verzie";
    }
  }

  // Načítanie A3 URL zo storage
  if (apiUrlInput) {
    try {
      const res = await chrome.storage.sync.get([STORAGE_KEY_API_URL]);
      apiUrlInput.value = res[STORAGE_KEY_API_URL] || DEFAULT_A3_URL;
    } catch (e) {
      apiUrlInput.value = DEFAULT_A3_URL;
    }
  }

  const saveUrl = async () => {
    if (!apiUrlInput) return;
    const url = apiUrlInput.value.trim() || DEFAULT_A3_URL;
    try {
      await chrome.storage.sync.set({ [STORAGE_KEY_API_URL]: url });
    } catch (e) {
      console.error("ALF popup – chyba pri ukladaní URL:", e);
    }
  };

  if (saveUrlBtn) {
    saveUrlBtn.addEventListener("click", saveUrl);
  }

  const openDevtoolsBtn = document.getElementById("openDevtools");
  if (openDevtoolsBtn) {
    openDevtoolsBtn.addEventListener("click", () => {
      const url = chrome.runtime.getURL("devtool/devtools-panel.html");
      chrome.tabs.create({ url });
    });
  }
});

