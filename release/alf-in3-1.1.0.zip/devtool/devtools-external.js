// `external` of a step: the recipe primitives the engine (arch-it3ct external-catalog.js) already filled with values.
// The panel outlives page navigations, so it drives the recipe: host waits are checked on the tab,
// element primitives are injected into the page and retried while the next page is still loading.

const EXTERNAL_STEP_TIMEOUT_MS = 30000;
const EXTERNAL_POLL_MS = 300;

const externalSleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function describeExternalPrimitive(primitive) {
  const parts = [primitive.do, primitive.css, primitive.text, primitive.host, primitive.file, primitive.secret ? "***" : primitive.value];
  return parts.filter((part) => part !== undefined).join(" ");
}

function externalHostOf(url) {
  try {
    return new URL(url).host;
  } catch (e) {
    return "";
  }
}

async function waitForTabHost(tabId, host) {
  const deadline = Date.now() + EXTERNAL_STEP_TIMEOUT_MS;
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId);
    if (externalHostOf(tab.url) === host && tab.status === "complete") return;
    await externalSleep(EXTERNAL_POLL_MS);
  }
  throw new Error(`stránka sa nedostala na „${host}“`);
}

// Runs inside the page (injected with chrome.scripting, so it does not depend on the content script version); must stay self-contained.
function externalPagePrimitive(primitive) {
  const normalized = (text) => String(text || "").replace(/\s+/g, " ").trim();
  if (primitive.do === "click") {
    const el = document.querySelector(primitive.css);
    if (!el) return false;
    el.click();
    return true;
  }
  if (primitive.do === "clickText") {
    const el = Array.from(document.querySelectorAll(primitive.css)).find((candidate) => normalized(candidate.textContent).includes(normalized(primitive.text)));
    if (!el) return false;
    el.click();
    return true;
  }
  if (primitive.do === "fill") {
    const el = document.querySelector(primitive.css);
    if (!el) return false;
    const valueSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    valueSetter.call(el, primitive.value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  return false;
}

async function runPrimitiveInPage(tabId, primitive) {
  try {
    const [injection] = await chrome.scripting.executeScript({ target: { tabId }, func: externalPagePrimitive, args: [primitive] });
    return Boolean(injection && injection.result);
  } catch (error) {
    return false;
  }
}

async function runElementPrimitive(tabId, primitive) {
  const deadline = Date.now() + EXTERNAL_STEP_TIMEOUT_MS;
  while (Date.now() < deadline) {
    if (await runPrimitiveInPage(tabId, primitive)) return;
    await externalSleep(EXTERNAL_POLL_MS);
  }
  throw new Error(`element „${primitive.css}“ sa nenašiel`);
}

async function runExternalPrimitive(tabId, primitive, clientHost) {
  if (primitive.do === "armFakeAutogram") return;
  if (primitive.do === "waitForAutogramSigned") {
    pauseAutoRun("podpíš dokument v Autograme a stlač Continue");
    return;
  }
  if (primitive.do === "waitForHost") return waitForTabHost(tabId, primitive.host);
  if (primitive.do === "waitForClientHost") return waitForTabHost(tabId, clientHost);
  return runElementPrimitive(tabId, primitive);
}

// Runs every call of `step.external` in order; throws an Error naming the adapter and primitive that failed.
async function runExternalCalls(tabId, calls, clientHost) {
  for (const call of calls || []) {
    for (const primitive of call.recipe) {
      alfLog("info", `external ${call.name}: ${describeExternalPrimitive(primitive)}`);
      try {
        await runExternalPrimitive(tabId, primitive, clientHost);
      } catch (error) {
        throw new Error(`external „${call.name}“, krok „${describeExternalPrimitive(primitive)}“: ${error.message}`);
      }
    }
  }
}
