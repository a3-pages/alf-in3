/** Assertion engine: runs lines like `isEqual("status-field", "aktívny")` against the current page. */

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Builds a text matcher with optional glob wildcard (*).
 * "Byt*"    → prefix match (starts with "Byt")
 * "*priestor" → suffix match
 * "*text*"  → contains match
 * "exact"   → exact match
 */
function buildTextMatcher(pattern) {
  const text = String(pattern == null ? "" : pattern).trim();
  if (!text.includes("*")) {
    return (actual) => String(actual).trim() === text;
  }
  const regexSource = text.split("*").map(escapeRegExp).join(".*");
  const regex = new RegExp(`^${regexSource}$`);
  return (actual) => regex.test(String(actual).trim());
}

function classifyWildcardMode(pattern) {
  const text = String(pattern || "");
  const wildcardCount = (text.match(/\*/g) || []).length;
  const starts = text.startsWith("*");
  const ends = text.endsWith("*");

  if (wildcardCount === 1 && !starts && ends) return "prefix";
  if (wildcardCount === 1 && starts && !ends) return "suffix";
  if (wildcardCount === 2 && starts && ends && text.slice(1, -1).indexOf("*") === -1) {
    return "contains";
  }

  return "glob";
}

function buildTestIdPatternMatcher(testId) {
  const raw = testId == null ? "" : String(testId);
  const hasWildcard = raw.includes("*");

  if (!hasWildcard) {
    return {
      raw,
      hasWildcard: false,
      mode: "exact",
      matches: (value) => String(value || "") === raw,
    };
  }

  const regexSource = raw
    .split("*")
    .map((part) => escapeRegExp(part))
    .join(".*");
  const regex = new RegExp(`^${regexSource}$`);

  return {
    raw,
    hasWildcard: true,
    mode: classifyWildcardMode(raw),
    matches: (value) => regex.test(String(value || "")),
  };
}

function collectMatchedTestIdElements(testId, options) {
  const cfg = options && typeof options === "object" ? options : {};
  const dataTestOnly = !!cfg.dataTestOnly;
  const matcher = buildTestIdPatternMatcher(testId);

  let candidates = [];
  if (matcher.hasWildcard) {
    const selector = dataTestOnly ? "[data-test-id]" : "[data-test-id], [id]";
    candidates = Array.from(document.querySelectorAll(selector));
  } else {
    const key = matcher.raw;
    const escaped = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(key) : key;
    const dataMatches = Array.from(document.querySelectorAll(`[data-test-id="${escaped}"]`));

    if (dataTestOnly) {
      candidates = dataMatches;
    } else {
      candidates = dataMatches;
      const byId = document.getElementById(key);
      if (byId && !candidates.includes(byId)) {
        candidates.push(byId);
      }
    }
  }

  const seen = new Set();
  const elements = [];
  const matchedIds = [];

  for (const el of candidates) {
    if (!el || seen.has(el)) continue;

    const key = dataTestOnly
      ? String(el.getAttribute("data-test-id") || "")
      : String(el.getAttribute("data-test-id") || el.id || "");

    if (!key) continue;
    if (!matcher.matches(key)) continue;

    seen.add(el);
    elements.push(el);
    matchedIds.push(key);
  }

  return {
    ...matcher,
    elements,
    matchedIds,
    matchedCount: elements.length,
  };
}

function requireMatchedTestIdElements(testId, assertionName, options) {
  const match = collectMatchedTestIdElements(testId, options);
  if (match.matchedCount > 0) {
    return match;
  }

  const key = testId == null ? "" : String(testId);
  const suffix = assertionName ? ` (${assertionName})` : "";
  throw new Error(`Not found datatestid: ${key}${suffix}`);
}

function alfGetElValue(el) {
  if (!el) return "";
  if (
    el instanceof HTMLInputElement ||
    el instanceof HTMLTextAreaElement ||
    el instanceof HTMLSelectElement
  ) {
    return el.value;
  }
  // A tags multiselect keeps all its options in the DOM; only the selected tags are its value.
  if (el.querySelector(".multiselect-tags")) {
    return Array.from(el.querySelectorAll(".multiselect-tag"), (t) => t.textContent.trim()).join(" ");
  }
  return el.textContent.trim();
}

function alfIsVisible(el) {
  if (!el || !el.isConnected) return false;
  if (el.hidden) return false;
  if (el.getAttribute("aria-hidden") === "true") return false;

  const style = window.getComputedStyle(el);
  if (style.display === "none") return false;
  if (style.visibility === "hidden" || style.visibility === "collapse") return false;

  // display:contents elements (e.g. our <ace-is-*>/<acm-*> metadata wrappers)
  // never get a box of their own - getBoundingClientRect() on them is always
  // {0,0,0,0} even though their children render fully. We can't just return
  // true here: if an ancestor is display:none/hidden, the children's rects
  // collapse to {0,0,0,0} too, and unconditionally returning true would wrongly
  // mark such an ancestor-hidden wrapper as visible. Fall back to checking
  // whether any child actually has a non-zero rendered box instead.
  if (style.display === "contents") {
    return Array.prototype.some.call(el.children, (child) => {
      const childRect = child.getBoundingClientRect();
      return childRect.width > 0 || childRect.height > 0;
    });
  }

  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}


/** Normalizes `{ before, after }` (or a ready list) into assertion lines; before + after are chained because one click runs both. */
function normalizeAssertionsInput(assertions) {
  if (assertions == null) return [];
  // A line starting with `#` is a comment (a disabled assertion) and is skipped.
  const trimmed = (list) => list.map((entry) => String(entry).trim()).filter((line) => line !== "" && !line.startsWith("#"));
  if (Array.isArray(assertions)) return trimmed(assertions);
  if (typeof assertions === "object") {
    const before = Array.isArray(assertions.before) ? assertions.before : [];
    const after = Array.isArray(assertions.after) ? assertions.after : [];
    return trimmed([...before, ...after]);
  }
  return null;
}

/** Splits call arguments on commas, respecting quotes and nested (), [], {}. */
function splitAssertionArgs(argsStr) {
  const result = [];
  let current = "";
  let inQuotes = false;
  let quoteChar = "";
  let roundDepth = 0;
  let squareDepth = 0;
  let curlyDepth = 0;

  for (let i = 0; i < argsStr.length; i++) {
    const ch = argsStr[i];

    if (inQuotes) {
      if (ch === "\\" && i + 1 < argsStr.length) {
        current += ch + argsStr[i + 1];
        i += 1;
        continue;
      }
      if (ch === quoteChar) {
        inQuotes = false;
      }
      current += ch;
      continue;
    }

    if (ch === '"' || ch === "'") {
      inQuotes = true;
      quoteChar = ch;
      current += ch;
      continue;
    }

    if (ch === "(") roundDepth += 1;
    else if (ch === ")") roundDepth = Math.max(0, roundDepth - 1);
    else if (ch === "[") squareDepth += 1;
    else if (ch === "]") squareDepth = Math.max(0, squareDepth - 1);
    else if (ch === "{") curlyDepth += 1;
    else if (ch === "}") curlyDepth = Math.max(0, curlyDepth - 1);

    if (ch === "," && roundDepth === 0 && squareDepth === 0 && curlyDepth === 0) {
      result.push(current.trim());
      current = "";
      continue;
    }

    current += ch;
  }

  const last = current.trim();
  if (last !== "" || result.length > 0) {
    result.push(last);
  }
  return result;
}

function isQuotedLiteral(token) {
  if (!token || token.length < 2) return false;
  const first = token[0];
  const last = token[token.length - 1];
  return (first === '"' && last === '"') || (first === "'" && last === "'");
}

function parseQuotedLiteral(token) {
  if (token[0] === '"') {
    return JSON.parse(token);
  }

  const body = token.slice(1, -1);
  return body.replace(/\\'/g, "'").replace(/\\\\/g, "\\");
}

function isNumericLiteral(token) {
  return /^[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?$/.test(token);
}

function tryGetPathValue(source, pathParts) {
  if (!source || typeof source !== "object") {
    return { found: false, value: undefined };
  }

  let cursor = source;
  for (const part of pathParts) {
    if (cursor == null || (typeof cursor !== "object" && typeof cursor !== "function")) {
      return { found: false, value: undefined };
    }

    if (!(part in cursor)) {
      return { found: false, value: undefined };
    }

    cursor = cursor[part];
  }

  return { found: true, value: cursor };
}

function resolveTokenPath(token, scope) {
  const pathParts = token
    .split(".")
    .map((part) => part.trim())
    .filter(Boolean);

  if (pathParts.length === 0) {
    return { found: false, value: undefined };
  }

  const rootScope = scope && typeof scope === "object" ? scope : {};

  // Priamy lookup zo scope root (napr. stepIndex, data.foo)
  const direct = tryGetPathValue(rootScope, pathParts);
  if (direct.found) return direct;

  // Lookup cez data-mapu (najčastejší prípad pre unquoted dotted keys)
  const fromData = tryGetPathValue(rootScope.data, pathParts);
  if (fromData.found) return fromData;

  // Lookup v aktuálnom kroku (step.xxx)
  const fromStep = tryGetPathValue(rootScope.step, pathParts);
  if (fromStep.found) return fromStep;

  // Lookup v map
  if (rootScope.map && typeof rootScope.map === "object" && token in rootScope.map) {
    return { found: true, value: rootScope.map[token] };
  }

  const fromMap = tryGetPathValue(rootScope.map, pathParts);
  if (fromMap.found) return fromMap;

  return { found: false, value: undefined };
}

function evaluateAssertionArg(token, scope) {
  const text = token == null ? "" : String(token).trim();
  if (text === "") return "";
  if (isQuotedLiteral(text)) return parseQuotedLiteral(text);
  if (text === "true") return true;
  if (text === "false") return false;
  if (text === "null") return null;
  if (isNumericLiteral(text)) return Number(text);

  const resolved = resolveTokenPath(text, scope);
  if (resolved.found) {
    return resolved.value;
  }

  // Zachovanie spätnej kompatibility: neresolvnute unquoted tokeny berieme ako plain string.
  return text;
}

/** Parses one assertion like "isEqual(foo, bar)" into { fn, args, raw }; null when invalid. */
function parseAssertion(input, scope) {
  if (typeof input !== "string") return null;

  const raw = input.trim();
  const match = raw.match(/^(\w+)\s*\(([\s\S]*)\)\s*$/);
  if (!match) return null;

  const fn = match[1];
  const argsStr = match[2].trim();
  const tokens = argsStr === "" ? [] : splitAssertionArgs(argsStr);
  const args = [];

  for (const token of tokens) {
    try {
      args.push(evaluateAssertionArg(token, scope));
    } catch (e) {
      return {
        fn,
        args: [],
        raw,
        error: `Nevalidný argument "${token}": ${String(e)}`,
      };
    }
  }

  return { fn, args, raw };
}


const ALF_ASSERTIONS = {
  /** Používateľ je prihlásený – chýbajú tlačidlá prihlásenia a registrácie.
   *  Ak je zadaný user, hľadá sa jeho meno v hlavičke `.idsk-header__user.main`. */
  isAuthenticated(user) {
    const loginBtn = document.querySelector('[data-test-id="prihlasenie"]');
    const registerBtn = document.querySelector('[data-test-id="registracia"]');
    if (loginBtn || registerBtn) return false;

    if (user == null || !String(user).trim()) {
      return true;
    }

    const normalize = (value) =>
      String(value || "")
        .trim()
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");

    const needle = normalize(user);
    const userEls = document.querySelectorAll(".idsk-header__user.main");

    for (const el of userEls) {
      const text = normalize(el.textContent);
      if (text.includes(needle)) return true;
    }

    return false;
  },

  /** Používateľ NIE je prihlásený – existuje tlačidlo prihlásenia alebo registrácie. */
  isUnauthenticated() {
    return !!(
      document.querySelector('[data-test-id="prihlasenie"]') ||
      document.querySelector('[data-test-id="registracia"]')
    );
  },

  /** Aktuálna URL sedí na zadaný vzor (rovnaký wildcard formát ako kroky scenára). */
  urlMatches(url) {
    if (!url) {
       throw new Error("Nebola zadaná očakávaná URL.");
    }
    const expected = String(url).trim();
    // urlMatchesStep je definovaná v main.js, zdieľaný scope (late binding).
    const passed = urlMatchesStep(location.href, expected);
    if (!passed) {
       throw new Error(`URL sa nezhoduje. Aktuálna URL: "${location.href}"`);
    }
    return true;
  },

  /** Element je zaškrtnutý / aria-checked=true / má truthy hodnotu. */
  isTrue(testId) {
    const match = requireMatchedTestIdElements(testId, "isTrue");
    let actualStates = [];
    const passed = match.elements.some((el) => {
      let isTruth;
      let stateDesc;
      if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) {
        isTruth = el.checked;
        stateDesc = el.checked ? "checked=true" : "checked=false";
      } else {
        const ariaChecked = el.getAttribute("aria-checked");
        if (ariaChecked !== null) {
          isTruth = ariaChecked === "true";
          stateDesc = `aria-checked=${ariaChecked}`;
        } else {
          const val = alfGetElValue(el);
          isTruth = Boolean(val) && val !== "false" && val !== "0";
          stateDesc = `value="${val}"`;
        }
      }
      actualStates.push(stateDesc);
      return isTruth;
    });
    
    if (!passed) {
      throw new Error(`Žiadny z elementov nebol vyhodnotený ako "true". Aktuálne stavy: ${actualStates.join(', ')}`);
    }
    return true;
  },

  /** Opak isTrue. */
  isFalse(testId) {
    const match = requireMatchedTestIdElements(testId, "isFalse");
    return match.elements.some((el) => {
      if (el instanceof HTMLInputElement && (el.type === "checkbox" || el.type === "radio")) {
        return !el.checked;
      }
      const ariaChecked = el.getAttribute("aria-checked");
      if (ariaChecked !== null) return ariaChecked !== "true";
      const val = alfGetElValue(el);
      return !val || val === "false" || val === "0";
    });
  },

  /** Hodnota (alebo textContent) elementu sa rovná zadanému reťazcu. */
  isEqual(testId, value) {
    const match = requireMatchedTestIdElements(testId, "isEqual");
    const expected = String(value != null ? value : "");
    return match.elements.some((el) => alfGetElValue(el) === expected);
  },

  /** Opak isEqual. */
  isNotEqual(testId, value) {
    const match = requireMatchedTestIdElements(testId, "isNotEqual");
    const expected = String(value != null ? value : "");
    return match.elements.some((el) => alfGetElValue(el) !== expected);
  },

  /** Never fails: returns the element's value/text in `info.captured` for the devtools panel to store (variables live there, the content script reloads on every navigation). */
  captureFromDti(testId, varName) {
    const match = requireMatchedTestIdElements(testId, "captureFromDti");
    const value = alfGetElValue(match.elements[0]);
    return { passed: true, info: { captured: value, varName: String(varName != null ? varName : "") } };
  },

  /** Like captureFromDti, but matches a regex against the visible page text instead of an element. */
  captureFromText(pattern, varName) {
    const text = document.body.innerText.replace(/\s+/g, " ");
    const found = new RegExp(pattern).exec(text);
    if (!found) {
      throw new Error(`Text stránky nezodpovedá /${pattern}/`);
    }
    const value = found[1] !== undefined ? found[1] : found[0];
    return { passed: true, info: { captured: value, varName: String(varName != null ? varName : "") } };
  },

  /** Element má prázdnu hodnotu / text. */
  isEmpty(testId) {
    const match = requireMatchedTestIdElements(testId, "isEmpty");
    const actualValues = match.elements.map(el => alfGetElValue(el));
    const passed = actualValues.some(val => val === "");
    if (!passed) {
      throw new Error(`Očakávala sa prázdna hodnota, ale nájdené: "${actualValues.join('", "')}"`);
    }
    return true;
  },

  /** Opak isEmpty. */
  isNotEmpty(testId) {
    const match = requireMatchedTestIdElements(testId, "isNotEmpty");
    return match.elements.some((el) => alfGetElValue(el) !== "");
  },

  /** Zhoda textu v <title>. Podporuje wildcard * (napr. "Byt*"). */
  titleIs(text) {
    if (text == null) return false;
    return buildTextMatcher(text)(document.title);
  },

  /** Zhoda textu v <h1>. Ak je ich viac, nevyhodí chybu, ale vypíše info. Podporuje wildcard * (napr. "Byt*"). */
  h1Is(text) {
    const headingEls = Array.from(document.querySelectorAll("h1"));
    if (headingEls.length === 0) {
      throw new Error(`h1Is assertion failed: expected at least one h1, found 0`);
    }
    if (text == null) return false;

    const matcher = buildTextMatcher(text);
    const passed = headingEls.some((el) => matcher(el.textContent));

    if (headingEls.length > 1) {
      return {
        passed,
        info: {
          level: "info",
          type: "h1Is-multiple",
          message: `h1Is found ${headingEls.length} h1 elements (expected 1).`,
          actual: headingEls.length,
        },
      };
    }

    return passed;
  },

  /** Breadcrumbs podľa viditeľného textu v poradí. Každý label podporuje wildcard * (napr. "Byt*"). */
  breadcrumbsAre(...paths) {
    const expected = paths
      .map((p) => (p == null ? "" : String(p).trim()))
      .filter((p) => p !== "");
    if (expected.length === 0) return false;

    const root = document.querySelector(".govuk-breadcrumbs__list");
    if (!root) return false;

    const actual = Array.from(root.querySelectorAll(".govuk-breadcrumbs__list-item"))
      .map((item) => {
        const labelEl = item.querySelector("a, span");
        return (labelEl ? labelEl.textContent : item.textContent || "").trim();
      })
      .filter((v) => v !== "");

    if (actual.length !== expected.length) return false;
    for (let i = 0; i < expected.length; i++) {
      if (!buildTextMatcher(expected[i])(actual[i])) return false;
    }
    return true;
  },

  /** Toast/alert s success triedou (voliteľne obsahujúci daný text). */
  hasSuccessMessage(text) {
    const all = Array.from(
      document.querySelectorAll(
        '[role="alert"], .toast, .notification, [class*="toast"], [class*="notification"], [class*="snackbar"]',
      ),
    );
    const pool = all.filter((el) => {
      const cls = (el.className || "").toLowerCase();
      return (
        cls.includes("success") ||
        cls.includes("is-success") ||
        el.dataset.type === "success"
      );
    });
    const candidates = pool.length > 0 ? pool : all;
    if (!text) return candidates.length > 0;
    const needle = String(text).trim().toLowerCase();
    return candidates.some((el) => el.textContent.trim().toLowerCase().includes(needle));
  },

  /** Toast/alert s error triedou alebo .govuk-error-summary (voliteľne obsahujúci text). */
  hasErrorMessage(text) {
    const all = Array.from(
      document.querySelectorAll(
        '[role="alert"], .govuk-error-summary, .toast, [class*="toast"], [class*="error"], [class*="notification"]',
      ),
    );
    const pool = all.filter((el) => {
      const cls = (el.className || "").toLowerCase();
      return (
        cls.includes("error") ||
        cls.includes("is-error") ||
        el.dataset.type === "error"
      );
    });
    const candidates = pool.length > 0 ? pool : all;
    if (!text) return candidates.length > 0;
    const needle = String(text).trim().toLowerCase();
    return candidates.some((el) => el.textContent.trim().toLowerCase().includes(needle));
  },

  /** V govuk-form-group rodičovi poľa existuje chybová hláška (voliteľne s textom). */
  hasValidationError(testId, text) {
    const match = requireMatchedTestIdElements(testId, "hasValidationError");
    const needle = String(text == null ? "" : text).trim().toLowerCase();

    return match.elements.some((el) => {
      const parent =
        el.closest(".govuk-form-group, .form-group, .field, .input-wrapper") ||
        el.parentElement;
      if (!parent) return false;

      const errorEl = parent.querySelector(
        '.govuk-error-message, .error-message, .field-error, [class*="error-message"], [class*="validation-error"]',
      );
      if (!errorEl) return false;
      if (!needle) return true;

      return errorEl.textContent.trim().toLowerCase().includes(needle);
    });
  },

  /** Počet elementov s daným data-test-id sedí. */
  countByTestIdIs(testId, number) {
    const expected = Number(number);
    const match = requireMatchedTestIdElements(testId, "countByTestIdIs", { dataTestOnly: true });
    const actual = match.matchedCount;
    const passed = actual === expected;

    if (match.hasWildcard && actual > expected) {
      return {
        passed,
        info: {
          level: "info",
          type: "countByTestIdIs-overflow",
          message: `countByTestIdIs pattern \"${match.raw}\" found ${actual} matches (expected ${expected}).`,
          pattern: match.raw,
          mode: match.mode,
          actual,
          expected,
        },
      };
    }

    return { passed };
  },

  /** Počet výskytov textu vo viditeľnom texte stránky sedí (case-insensitive); `*` zastúpi ľubovoľný text v rámci riadku. */
  textCount(text, number) {
    const needleRaw = String(text == null ? "" : text).trim();
    if (!needleRaw) return false;

    const bodyText = document.body && typeof document.body.innerText === "string"
      ? document.body.innerText
      : "";

    // `*` matches any text within one line; without it this is a plain substring count.
    const parts = needleRaw.toLowerCase().split("*");
    const escape = (part) => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const count = parts.every((part) => part === "")
      ? 0
      : (bodyText.toLowerCase().match(new RegExp(parts.map(escape).join("[^\\n]*"), "g")) || []).length;

    const expected = Number(number);
    if (count !== expected) {
      throw new Error(`Text "${needleRaw}" nájdený ${count}-krát (očakávalo sa ${expected})`);
    }
    return true;
  },

  /** Element existuje a je viditeľný. */
  isVisible(testId) {
    const match = requireMatchedTestIdElements(testId, "isVisible");
    return match.elements.some((el) => alfIsVisible(el));
  },

  /** Element existuje a je povolený. */
  isEnabled(testId) {
    const match = requireMatchedTestIdElements(testId, "isEnabled");
    return match.elements.some((el) => {
      if ("disabled" in el) {
        return !el.disabled;
      }
      return el.getAttribute("aria-disabled") !== "true";
    });
  },

  /** Element existuje a je zablokovaný. */
  isDisabled(testId) {
    const match = requireMatchedTestIdElements(testId, "isDisabled");
    return match.elements.some((el) => {
      if ("disabled" in el) {
        return !!el.disabled;
      }
      return el.getAttribute("aria-disabled") === "true";
    });
  },

  /** Element existuje a obsahuje text (case-insensitive). */
  textContains(testId, text) {
    const match = requireMatchedTestIdElements(testId, "textContains");
    const needle = String(text == null ? "" : text).trim().toLowerCase();
    if (!needle) return false;
    return match.elements.some((el) => alfGetElValue(el).toLowerCase().includes(needle));
  },

  /** Element s daným data-test-id existuje v DOM (alias pre "identifikator"). */
  elementExists(testId) {
    return collectMatchedTestIdElements(testId).matchedCount > 0;
  },

  /** Combobox/multiselect zobrazuje daný label (text v .multiselect-single-label-text). */
  comboboxSelectedIs(testId, value) {
    const match = requireMatchedTestIdElements(testId, "comboboxSelectedIs");
    const expected = String(value == null ? "" : value).trim().toLowerCase();
    return match.elements.some((el) => {
      const labelEl = el.querySelector(".multiselect-single-label-text");
      if (labelEl) {
        return labelEl.textContent.trim().toLowerCase() === expected;
      }
      // Fallback: aria-label na role=combobox
      const combobox = el.querySelector("[role=combobox]") || (el.getAttribute("role") === "combobox" ? el : null);
      if (combobox) {
        return (combobox.getAttribute("aria-label") || "").trim().toLowerCase() === expected;
      }
      return false;
    });
  },

  /** Combobox/multiselect má opciu s daným textom vybratú (aria-selected="true"). */
  comboboxHasSelectedOption(testId, value) {
    const match = requireMatchedTestIdElements(testId, "comboboxHasSelectedOption");
    const expected = String(value == null ? "" : value).trim().toLowerCase();
    return match.elements.some((el) => {
      const options = Array.from(el.querySelectorAll('[role="option"]'));
      return options.some(
        (opt) =>
          opt.getAttribute("aria-selected") === "true" &&
          (opt.getAttribute("aria-label") || opt.textContent || "").trim().toLowerCase() === expected,
      );
    });
  },
};


/** Runs the assert lines; returns { passed, results: [{ fn, args, passed, error?, info?, raw? }] }. */
function runAssertions(assertions, context) {
  const normalized = normalizeAssertionsInput(assertions);

  if (normalized == null) {
    return {
      passed: false,
      results: [
        {
          fn: "",
          args: [],
          passed: false,
          error: "Nevalidný formát assert. Očakáva sa `assert: |` (string).",
          raw: typeof assertions === "string" ? assertions : JSON.stringify(assertions),
        },
      ],
    };
  }

  if (normalized.length === 0) {
    return { passed: true, results: [] };
  }

  const results = normalized.map((entry) => {
    const parsed = parseAssertion(entry, context);
    if (!parsed) {
      console.warn(`ALF assertion invalid syntax: [${entry}]`);
      return {
        fn: "",
        args: [],
        passed: false,
        error: "Nevalidný syntax assertácie",
        raw: entry,
      };
    }

    if (parsed.error) {
      console.warn(`ALF assertion parse error in [${parsed.raw}]:`, parsed.error);
      return {
        fn: parsed.fn,
        args: [],
        passed: false,
        error: parsed.error,
        raw: parsed.raw,
      };
    }

    const fn = ALF_ASSERTIONS[parsed.fn];
    if (typeof fn !== "function") {
      console.warn(`ALF assertion unknown: [${parsed.raw}]`);
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: false,
        error: `Neznáma assertácia: "${parsed.fn}"`,
        raw: parsed.raw,
      };
    }

    try {
      const outcome = fn(...parsed.args);
      const passed =
        outcome && typeof outcome === "object" && "passed" in outcome
          ? !!outcome.passed
          : !!outcome;

      const result = {
        fn: parsed.fn,
        args: parsed.args,
        passed,
        raw: parsed.raw,
      };

      if (outcome && typeof outcome === "object" && outcome.info) {
        result.info = outcome.info;
      }

      if (!passed) {
        console.warn(`ALF assertion failed: [${parsed.raw}]`);
      }

      return result;
    } catch (e) {
      const errorText = e && typeof e === "object" && "message" in e ? e.message : String(e);
      console.warn(`ALF assertion error in [${parsed.raw}]:`, errorText);
      return {
        fn: parsed.fn,
        args: parsed.args,
        passed: false,
        error: String(errorText),
        raw: parsed.raw,
      };
    }
  });

  return { passed: results.every((r) => r.passed), results };
}
