// UI state and list helpers for ALF DevTools.
let currentScenariosMap = new Map();
let currentPresetsMap = new Map();
let currentBaseUrl = null;
let currentProject = "";

function currentPresetValue() {
  const presetSelect = $("presetSelect");
  return presetSelect && presetSelect.value ? String(presetSelect.value).trim() : "";
}

function fillSelect(selectEl, list) {
  selectEl.innerHTML = "";
  if (selectEl.id === "apiSelect") currentScenariosMap.clear();

  if (!list || list.length === 0) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = "(Žiadne položky z API)";
    selectEl.appendChild(opt);
    if (selectEl.id === "apiSelect") updateScenarioDescription();
    return;
  }

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "(Vyber flow)";
  selectEl.appendChild(placeholder);

  for (const item of list) {
    if (!item || typeof item !== "object") continue;
    const id = item.id != null ? String(item.id) : "";
    const value = item.value != null ? String(item.value) : "";
    if (!id && !value) continue;

    if (selectEl.id === "apiSelect") currentScenariosMap.set(id, item);

    const opt = document.createElement("option");
    opt.value = id;
    opt.textContent = id.replace(/^qa\/alf\//, "").replace(/\.alf\.md$/, "");
    opt.dataset.id = id;
    selectEl.appendChild(opt);
  }

  if (selectEl.id === "apiSelect") updateScenarioDescription();
  if (typeof syncCustomDropdown === "function") syncCustomDropdown(selectEl.id);
}

function updateScenarioDescription() {
  const apiSelect = $("apiSelect");
  const scenarioDescription = $("scenarioDescription");
  const scenarioDiagnostics = $("scenarioDiagnostics");
  if (!apiSelect || !scenarioDescription) return;

  const val = apiSelect.value;
  if (!val || !currentScenariosMap.has(val)) {
    scenarioDescription.style.display = "none";
    renderDiagnostics(scenarioDiagnostics, []);
    return;
  }

  const scenario = currentScenariosMap.get(val);
  renderDiagnostics(scenarioDiagnostics, scenario.diagnostics);
  const { before, after } = scenario.condition || {};
  const conditionLines = [["before run", before], ["after run", after]].filter(([, text]) => text);
  if (conditionLines.length) {
    scenarioDescription.textContent = "";
    for (const [label, text] of conditionLines) {
      const line = document.createElement("div");
      const strong = document.createElement("strong");
      strong.textContent = `${label}:`;
      line.append(strong, ` ${text}`);
      scenarioDescription.appendChild(line);
    }
    scenarioDescription.style.display = "block";
  } else {
    scenarioDescription.style.display = "none";
  }
}

// Diagnostics come from the engine already worded in Slovak
// ({ level: "error" | "warning", text }) — shown one per line.
function renderDiagnostics(el, diagnostics) {
  if (!el) return;
  el.textContent = "";
  const list = Array.isArray(diagnostics) ? diagnostics : [];
  for (const d of list) {
    const line = document.createElement("div");
    const isError = d.level === "error";
    line.style.color = isError ? "#f85149" : "#d29922";
    line.textContent = `${isError ? "✗" : "⚠"} ${d.text}`;
    el.appendChild(line);
  }
  el.style.display = list.length ? "block" : "none";
}

function updatePresetDescription() {
  const presetSelect = $("presetSelect");
  const presetDescription = $("presetDescription");
  const presetDiagnostics = $("presetDiagnostics");
  if (!presetSelect || !presetDescription) return;

  const val = presetSelect.value;
  if (!val || !currentPresetsMap.has(val)) {
    presetDescription.style.display = "none";
    renderDiagnostics(presetDiagnostics, []);
    return;
  }

  const preset = currentPresetsMap.get(val);
  renderDiagnostics(presetDiagnostics, preset.diagnostics);
  if (preset.description) {
    presetDescription.textContent = preset.description;
    presetDescription.style.display = "block";
  } else {
    presetDescription.style.display = "none";
  }
}

async function loadProjectsIntoSelect() {
  const projectSelect = $("projectSelect");
  const clientSection = $("clientSection");
  if (!projectSelect) return;
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) return;

  const stored = await loadStoredProject();

  let projects = [];
  try {
    projects = await fetchProjects(baseUrl);
  } catch (e) {
    alfLog("error", "chyba pri načítaní projektov:", e && e.message ? e.message : e);
  }

  if (!Array.isArray(projects) || projects.length === 0) {
    if (clientSection) clientSection.style.display = "none";
    projectSelect.innerHTML = "";
    currentProject = "";
    return;
  }

  if (clientSection) clientSection.style.display = "";
  projectSelect.innerHTML = "";
  for (const p of projects) {
    const opt = document.createElement("option");
    opt.value = p;
    opt.textContent = p;
    projectSelect.appendChild(opt);
  }

  const resolved = stored && projects.includes(stored) ? stored : projects[0];
  projectSelect.value = resolved;
  if (resolved !== currentProject) {
    currentProject = resolved;
  }
  if (resolved !== stored) {
    await saveProject(resolved);
  }
}

async function loadPresetsIntoSelect() {
  const presetSelect = $("presetSelect");
  if (!presetSelect) return;
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) return;

  const currentVal = presetSelect.value;
  presetSelect.innerHTML = '<option value="">(Žiadny preset)</option>';
  currentPresetsMap.clear();

  try {
    const presets = await fetchPresets(baseUrl);
    if (Array.isArray(presets)) {
      for (const preset of presets) {
        currentPresetsMap.set(preset.id, preset);
        const opt = document.createElement("option");
        const idParts = String(preset.id || "").split("/");
        const envTag = idParts.length > 1 ? idParts[0] : "";
        const presetName = preset.title || (idParts.length > 1 ? idParts.slice(1).join("/") : preset.id);
        opt.value = preset.id;
        opt.textContent = presetName;
        opt.dataset.env = envTag;
        presetSelect.appendChild(opt);
      }
      if (currentPresetsMap.has(currentVal)) {
        presetSelect.value = currentVal;
      } else if (!currentVal) {
        const stored = await loadStoredValue(STORAGE_KEY_PRESET);
        if (stored && currentPresetsMap.has(stored)) presetSelect.value = stored;
      }
    }
  } catch (e) {
    alfLog("error", "chyba pri načítaní presetov:", e && e.message ? e.message : e);
  }
  updatePresetDescription();
  if (typeof syncCustomDropdown === "function") syncCustomDropdown("presetSelect");
}

async function loadSuitesIntoSelect() {
  const suiteSelect = $("suiteSelect");
  if (!suiteSelect) return;
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) return;

  const currentSuite = suiteSelect.value;
  suiteSelect.innerHTML = '<option value="">(Všetky scenáre)</option>';

  try {
    const suites = await fetchSuites(baseUrl);
    if (Array.isArray(suites)) {
      for (const suite of suites) {
        const opt = document.createElement("option");
        opt.value = suite;
        opt.textContent = suite;
        suiteSelect.appendChild(opt);
      }
      if (suites.includes(currentSuite)) {
        suiteSelect.value = currentSuite;
      } else if (!currentSuite) {
        const stored = await loadStoredValue(STORAGE_KEY_SUITE);
        if (stored && suites.includes(stored)) suiteSelect.value = stored;
      }
    }
  } catch (e) {
    alfLog("error", "chyba pri načítaní suites:", e && e.message ? e.message : e);
  }
  if (typeof syncCustomDropdown === "function") syncCustomDropdown("suiteSelect");
  setSuiteSectionVisible(suiteSelect.options.length > 1);
}

function setSuiteSectionVisible(visible) {
  const suiteSection = $("suiteSection");
  if (suiteSection) suiteSection.style.display = visible ? "" : "none";
}

async function loadScenariosIntoSelect() {
  const apiSelect = $("apiSelect");
  const suiteSelect = $("suiteSelect");
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) return;

  const currentScenario = apiSelect ? apiSelect.value : "";
  const presetName = currentPresetValue();
  if (!presetName) {
    fillSelect(apiSelect, []);
    alfLog("info", "scenáre sa nenačítali, vyber preset.");
    return;
  }

  try {
    const suiteName = suiteSelect ? suiteSelect.value : "";
    fetchAssertionCatalog(baseUrl);
    const list = await fetchScenarios(baseUrl, suiteName);
    alfLog("info", `načítaných scenárov: ${list.length} (preset: ${presetName}${suiteName ? `, suite: ${suiteName}` : ""})`);
    fillSelect(apiSelect, list);
    if (apiSelect && currentScenario && Array.isArray(list) && list.some((item) => item && String(item.id) === String(currentScenario))) {
      apiSelect.value = currentScenario;
      updateScenarioDescription();
      if (typeof syncCustomDropdownSelected === "function") syncCustomDropdownSelected("apiSelect");
    } else if (apiSelect && !currentScenario) {
      const stored = await loadStoredValue(STORAGE_KEY_FLOW);
      if (stored && Array.isArray(list) && list.some((item) => item && String(item.id) === String(stored))) {
        apiSelect.value = stored;
        updateScenarioDescription();
        if (typeof syncCustomDropdownSelected === "function") syncCustomDropdownSelected("apiSelect");
        if (typeof loadScenario === "function") await loadScenario();
      }
    }
  } catch (e) {
    alfLog("error", "chyba pri načítaní scenárov:", e && e.message ? e.message : e);
    fillSelect(apiSelect, []);
  }
}

async function loadAmsInfoIntoUi() {
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) {
    renderAmsInfo(null, "A3 URL nie je nastavené");
    return;
  }

  const localLabel = localA3Label(baseUrl);
  if (localLabel) {
    const amsInfoEl = $("amsInfo");
    if (amsInfoEl) {
      amsInfoEl.classList.remove("error");
      amsInfoEl.textContent = `A3 AMS: ${localLabel}`;
      amsInfoEl.title = amsInfoEl.textContent;
    }
    return;
  }

  try {
    const amsInfo = await fetchAmsInfo(baseUrl);
    if (!amsInfo) {
      renderAmsInfo(null, "AMS endpoint vrátil prázdnu odpoveď");
      return;
    }
    renderAmsInfo(amsInfo);
  } catch (e) {
    const err = e && e.message ? e.message : String(e);
    renderAmsInfo(null, `nedostupné (${err})`);
  }
}
