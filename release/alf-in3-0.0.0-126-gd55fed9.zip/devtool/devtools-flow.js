// Scenario loading and step execution flow for ALF DevTools.
let lastScenario = null;
let lastScenarioIndex = -1;
let lastScenarioFilePath = null;
const STEP_MODE_ACTION = "action";
let currentStepMode = STEP_MODE_ACTION;
const lastAssertResultsByStep = new Map();
const lastRunStateByStep = new Map();

// Variables captured mid-scenario (captureFromDti/captureFromText) live here, not in the content script, which reloads on every navigation.
let scenarioVariables = {};

const VAR_PATTERN = /\{\{\s*([\w.-]+)\s*\}\}/g;

function substituteVars(value) {
  if (typeof value !== "string") return value;
  return value.replace(VAR_PATTERN, (match, name) =>
    Object.prototype.hasOwnProperty.call(scenarioVariables, name) ? scenarioVariables[name] : match);
}

function substituteVarsInAssert(assert) {
  if (typeof assert === "string") return substituteVars(assert);
  if (Array.isArray(assert)) return assert.map((line) => substituteVars(line));
  if (assert && typeof assert === "object") {
    const out = {};
    if (Array.isArray(assert.before)) out.before = assert.before.map((line) => substituteVars(line));
    if (Array.isArray(assert.after)) out.after = assert.after.map((line) => substituteVars(line));
    return out;
  }
  return assert;
}

function substituteVarsInMap(map) {
  if (!map || typeof map !== "object") return map;
  const out = {};
  for (const [key, value] of Object.entries(map)) {
    out[key] = substituteVars(value);
  }
  return out;
}

// The content script gets the scenario with {{name}} already resolved, so main.js/assertions.js never deal with variables.
function resolveVarsInScenario(scenario) {
  if (!Array.isArray(scenario)) return scenario;
  return scenario.map((step) => {
    if (!step || typeof step !== "object") return step;
    return {
      ...step,
      map: substituteVarsInMap(step.map),
      assert: substituteVarsInAssert(step.assert),
    };
  });
}

function harvestCapturedVars(assertResults) {
  const results = assertResults && Array.isArray(assertResults.results) ? assertResults.results : [];
  for (const r of results) {
    if (r && (r.fn === "captureFromDti" || r.fn === "captureFromText") && r.info && r.info.varName) {
      scenarioVariables[r.info.varName] = r.info.captured != null ? String(r.info.captured) : "";
    }
  }
}

function getStepAssertionLines(step) {
  const lines = (list) => (Array.isArray(list) ? list : []).map((entry) => String(entry).trim()).filter((line) => line !== "");
  return [...lines(step?.assert?.before), ...lines(step?.assert?.after)];
}

// Steps have no `url:`; a representative path is recovered from a `urlMatches("...")` assertion, if any.
function getStepUrlHint(step) {
  if (!step || typeof step !== "object") return null;
  const lines = getStepAssertionLines(step);
  for (const line of lines) {
    const m = /^urlMatches\(\s*["']([^"']+)["']\s*\)$/.exec(line);
    if (m) return m[1];
  }
  return null;
}

// A step runs in up to four phases: assert (before) → map → assert (after) → action.
// `assert` may be a plain list/string (= before) or { pre|before, post|after }.
function getStepPhaseAssertionLines(step, phase) {
  if (!step || typeof step !== "object") return [];
  const list = step.assert?.[phase];
  return (Array.isArray(list) ? list : []).map((entry) => String(entry).trim()).filter((line) => line !== "");
}

function stepHasMap(step) {
  return !!step && !!step.map && typeof step.map === "object" && Object.keys(step.map).length > 0;
}

function getStepPhases(step) {
  const phases = [];
  if (getStepPhaseAssertionLines(step, "before").length > 0) phases.push("before");
  if (stepHasMap(step)) phases.push("map");
  if (getStepPhaseAssertionLines(step, "after").length > 0) phases.push("after");
  phases.push("action");
  return phases;
}

function isPhaseDone(idx, phase) {
  if (phase === "action") return false;
  if (phase === "map") return !!(lastRunStateByStep.get(idx) || {}).mapDone;
  return !!(lastAssertResultsByStep.get(idx) || {})[phase];
}

function getCurrentPhaseForStep(idx) {
  const step = Array.isArray(lastScenario) ? lastScenario[idx] : null;
  return getStepPhases(step).find((phase) => !isPhaseDone(idx, phase)) || "action";
}
// Marker between client segments of a multi-client scenario: tells which client's host to navigate to next.
function isClientSwitchStep(step) {
  return !!step && typeof step === "object" && "client" in step && Object.keys(step).length === 1;
}

// Mirrors resolveAllClientHosts() in alf-playwright/src/scenario-loader.ts: host of a client in the nested `client.<client>.host` preset shape.
function resolveClientHost(preset, client) {
  const host = preset && preset.data && preset.data.client && preset.data.client[client] && preset.data.client[client].host;
  if (typeof host !== "string" || !host) return null;
  const trimmed = host.trim();
  return trimmed.startsWith("http") ? trimmed : `https://${trimmed}`;
}

// Flat `env` host of the selected preset — used as reset target when the first
// step declares no url (e.g. flows starting with a login include).
function getPresetFlatHost() {
  const presetSelect = $("presetSelect");
  const presetName = presetSelect ? presetSelect.value : "";
  const preset = presetName && currentPresetsMap.has(presetName) ? currentPresetsMap.get(presetName) : null;
  const env = preset && preset.env;
  if (typeof env !== "string" || !env.trim()) return null;
  try {
    return new URL(env.trim().startsWith("http") ? env.trim() : `https://${env.trim()}`).origin;
  } catch {
    return null;
  }
}

function stepLogPrefix() {
  return `[${lastScenarioIndex + 1}/${Array.isArray(lastScenario) ? lastScenario.length : 0}]`;
}

function setPrimaryButtonMode(mode) {
  currentStepMode = ["before", "map", "after", "action"].includes(mode) ? mode : mode === "assert" ? "before" : STEP_MODE_ACTION;
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (!runScenarioStepBtn) return;
  const isAssert = currentStepMode === "before" || currentStepMode === "after";
  runScenarioStepBtn.textContent = isAssert ? `Assert ${currentStepMode}` : currentStepMode === "map" ? "Map" : "Action";
  runScenarioStepBtn.classList.toggle("mode-assert", isAssert);
  runScenarioStepBtn.classList.toggle("mode-map", currentStepMode === "map");
}

function updateActionButtonState() {
  const runScenarioStepBtn = $("runScenarioStepBtn");
  const resetScenarioBtn = $("resetScenarioBtn");
  const prevScenarioStepBtn = $("prevScenarioStepBtn");
  const apiSelect = $("apiSelect");
  if (!runScenarioStepBtn && !resetScenarioBtn) return;

  if (!apiSelect || !apiSelect.value || !String(apiSelect.value).trim()) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (prevScenarioStepBtn) prevScenarioStepBtn.disabled = true;
    return;
  }

  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
    if (prevScenarioStepBtn) prevScenarioStepBtn.disabled = true;
    return;
  }

  if (runScenarioStepBtn) runScenarioStepBtn.disabled = false;
  if (prevScenarioStepBtn) prevScenarioStepBtn.disabled = lastScenarioIndex <= 0 && getDonePhases(lastScenarioIndex).length === 0;
}

function getDelayMsForStep(step) {
  if (!step || typeof step !== "object") return 500;
  const mapKeys = step.map && typeof step.map === "object" ? Object.keys(step.map) : [];
  const hasDelayedKeys = mapKeys.some((k) => /#toggle/i.test(String(k)) || /#search/i.test(String(k)));
  if (hasDelayedKeys) return 2000;
  if (mapKeys.length > 0) return 1000;
  return 500;
}

function applyDelayForCurrentStep() {
  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    updateActionButtonState();
    return;
  }
  const step = lastScenario[lastScenarioIndex];
  const delayMs = getDelayMsForStep(step);
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  if (delayMs > 0) setTimeout(() => updateActionButtonState(), delayMs);
  else updateActionButtonState();
}

function hideAssertSection() {
  const section = $("assertSection");
  if (section) section.style.display = "none";
}

// Assertion outcome is painted inline in "Current step" (see renderCurrentStepInfo);
// the separate Assertions block stays hidden.
function renderAssertionResults(assertResults) {
  hideAssertSection();
  if (assertResults) renderCurrentStepInfo();
}

function syncCurrentStepModeAndAssertions() {
  hideAssertSection();
  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    setPrimaryButtonMode(STEP_MODE_ACTION);
    updateActionButtonState();
    return;
  }

  setPrimaryButtonMode(getCurrentPhaseForStep(lastScenarioIndex));
  renderCurrentStepInfo();
  updateActionButtonState();
}

function appendStepKeyword(container, keyword) {
  const kw = document.createElement("span");
  kw.className = `step-kw step-kw-${keyword}`;
  kw.textContent = keyword;
  container.appendChild(kw);
}

function appendStepLine(container, text, state) {
  const line = document.createElement("div");
  line.className = `step-line${state ? ` step-${state}` : ""}`;
  line.textContent = text;
  container.appendChild(line);
}

let stepRenderHold = false;

// Keeps the just-executed step (map/action painted green) on screen briefly
// before "Current step" moves on to the next one.
function holdExecutedStepThenAdvance(executedIdx) {
  renderCurrentStepInfo(executedIdx, true);
  stepRenderHold = true;
  setTimeout(() => {
    stepRenderHold = false;
    renderCurrentStepInfo();
  }, 700);
}

function renderCurrentStepInfo(indexOverride, force = false) {
  const apiResult = $("apiResult");
  if (!apiResult) return;
  if (stepRenderHold && !force) return;
  apiResult.style.color = "";

  if (!Array.isArray(lastScenario) || lastScenario.length === 0) {
    apiResult.textContent = "Žiadny načítaný scenár.";
    return;
  }

  const totalSteps = lastScenario.length;
  const idx = typeof indexOverride === "number" && !Number.isNaN(indexOverride) ? indexOverride : lastScenarioIndex;
  if (idx < 0 || idx >= totalSteps) {
    apiResult.style.color = "#3fb950";
    apiResult.textContent = totalSteps > 0
      ? `✅ Všetkých ${totalSteps} krokov scenára bolo úspešne dokončených.`
      : "✅ Všetky kroky scenára boli úspešne dokončené.";
    return;
  }

  const step = lastScenario[idx] || {};

  if (isClientSwitchStep(step)) {
    apiResult.textContent = `Step ${idx + 1}/${totalSteps}\nswitch client → ${step.client}`;
    return;
  }

  apiResult.textContent = "";
  appendStepLine(apiResult, `Step ${idx + 1}/${totalSteps}  ${step.name || "-"}`, "title");

  const renderAssertPhase = (phase) => {
    const lines = getStepPhaseAssertionLines(step, phase);
    if (lines.length === 0) return;
    const results = ((lastAssertResultsByStep.get(idx) || {})[phase] || {}).results || null;
    const head = document.createElement("div");
    head.className = "step-head";
    appendStepKeyword(head, "assert");
    const tag = document.createElement("span");
    tag.className = "step-phase-tag";
    tag.textContent = phase;
    head.appendChild(tag);
    apiResult.appendChild(head);
    if (results && results.length > 0) {
      for (const r of results) {
        const label = r.raw || (r.fn ? `${r.fn}(${(r.args || []).join(", ")})` : "(neznáma assertácia)");
        const reason = r.error || (r.passed ? "" : assertionFailureText(r));
        appendStepLine(apiResult, `${r.passed ? "✓" : "✗"} ${label}${reason ? ` — ${reason}` : ""}`, r.passed ? "pass" : "fail");
      }
    } else {
      for (const line of lines) appendStepLine(apiResult, `• ${line}`);
    }
  };

  renderAssertPhase("before");

  const map = step.map && typeof step.map === "object" ? step.map : null;
  if (map && Object.keys(map).length > 0) {
    const runStateForMap = lastRunStateByStep.get(idx) || {};
    const missing = runStateForMap.mapMissing || [];
    const head = document.createElement("div");
    head.className = "step-head";
    appendStepKeyword(head, "map");
    apiResult.appendChild(head);
    for (const [k, v] of Object.entries(map)) {
      const valStr = v === null || v === undefined ? "" : String(v);
      const key = k.split("#")[0];
      appendStepLine(apiResult, `${k}: ${valStr}`, missing.includes(key) ? "fail" : runStateForMap.mapDone ? "pass" : "");
    }
  }

  renderAssertPhase("after");

  const actionName = step.action || step.actions || null;
  if (actionName) {
    const runState = lastRunStateByStep.get(idx);
    const head = document.createElement("div");
    head.className = "step-head";
    appendStepKeyword(head, "action");
    const value = document.createElement("span");
    const actionState = runState && (runState.found === false ? " step-fail" : runState.done ? " step-pass" : "");
    value.className = `step-action${actionState || ""}`;
    value.textContent = actionName;
    head.appendChild(value);
    apiResult.appendChild(head);
  }
}

function extractScenarios(result) {
  if (!result || typeof result !== "object") return null;
  const feature = (result.feature && typeof result.feature === "object" && result.feature) || (result.alf && typeof result.alf === "object" && result.alf) || null;
  if (!feature || !Array.isArray(feature.steps)) return null;
  return feature.steps;
}

function getStartUrl(result) {
  if (!result || typeof result !== "object") return null;
  let pathOrUrl = null;
  if (!pathOrUrl && typeof result.startUrl === "string") pathOrUrl = result.startUrl.trim();
  if (!pathOrUrl && result.feature?.startUrl) pathOrUrl = String(result.feature.startUrl).trim();
  if (!pathOrUrl && result.alf?.startUrl) pathOrUrl = String(result.alf.startUrl).trim();
  if (!pathOrUrl) {
    const steps = extractScenarios(result);
    const firstStep = Array.isArray(steps) && steps.length ? steps[0] : null;
    pathOrUrl = getStepUrlHint(firstStep);
  }
  return pathOrUrl || null;
}

async function loadScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const presetSelect = $("presetSelect");
  const filePath = apiSelect.value;
  const presetName = presetSelect ? presetSelect.value : "";

  if (!filePath) {
    apiResult.textContent = "";
    return;
  }
  if (!presetName) {
    apiResult.textContent = "Vyber preset, aby sa dal načítať scenár.";
    alfLog("warn", "scenár sa nenačítal, chýba preset.");
    return;
  }
  const baseUrl = currentBaseUrl ? currentBaseUrl.trim() : "";
  if (!baseUrl) {
    apiResult.textContent = "";
    return;
  }

  try {
    const result = await postAlfScenario(baseUrl, filePath, presetName);
    const scenarios = extractScenarios(result);
    if (!scenarios || scenarios.length === 0) return;

    const combinedSteps = scenarios.filter((s) => s && typeof s === "object");

    lastScenario = combinedSteps;
    lastScenarioFilePath = filePath;
    lastScenarioIndex = 0;
    scenarioVariables = {};
    lastAssertResultsByStep.clear();
    lastRunStateByStep.clear();

    renderCurrentStepInfo(0);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;

      if (chrome.action && tabId != null && totalSteps) {
        chrome.action.setBadgeBackgroundColor({ color: "#2563eb", tabId });
        chrome.action.setBadgeText({ text: `0/${totalSteps}`, tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge && totalSteps) stepBadge.textContent = `0/${totalSteps}`;
    } catch (e) {
      alfLog("warn", "nepodarilo sa nastaviť badge:", e && e.message ? e.message : e);
    }

    const startUrl = getStartUrl(result);
    let presetUrl = null;
    let targetOrigin = null;
    if (presetName && currentPresetsMap.has(presetName)) {
      const preset = currentPresetsMap.get(presetName);
      // Host of the project's client, else of the preset's first client; mirrors alf-playwright's resolvePresetHost().
      const nestedUrl = resolveClientHost(preset, currentProject);
      const firstHost = preset.env ? preset.env.trim() : "";
      let envUrl = nestedUrl || (firstHost ? (firstHost.startsWith("http") ? firstHost : `https://${firstHost}`) : "");
      if (envUrl) {
        try {
          presetUrl = envUrl;
          targetOrigin = new URL(envUrl).origin;
        } catch {}
      }
    }

    if (!startUrl) {
      if (presetUrl) {
        try {
          const inspected = chrome.devtools?.inspectedWindow;
          const tabId = inspected?.tabId;
          if (tabId != null) chrome.tabs.update(tabId, { url: presetUrl });
        } catch {}
      }
      return;
    }

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        if (!targetOrigin) {
          const currentHrefResult = await getInspectedTabUrl().catch(() => null);
          if (currentHrefResult) {
            try {
              const current = new URL(currentHrefResult);
              targetOrigin = current.origin;
            } catch {
              targetOrigin = null;
            }
          }
        }
        let targetUrl;
        if (startUrl.startsWith("http") || !targetOrigin) {
          targetUrl = startUrl;
        } else {
          const path = String(startUrl).trim();
          targetUrl = path.startsWith("/") ? targetOrigin + path : targetOrigin + "/" + path;
        }
        chrome.tabs.update(tabId, { url: targetUrl });
      }
    } catch (navErr) {
      alfLog("warn", "nepodarilo sa presmerovať stránku:", navErr && navErr.message ? navErr.message : navErr);
    }
  } catch (e) {
    alfLog("error", "chyba POST getAlfScenario:", e && e.message ? e.message : e);
    apiResult.textContent = e.message || String(e);
  }
}

function getCurrentStepContext() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const filePath = apiSelect.value;
  if (apiResult) apiResult.style.color = "";

  if (!filePath || !lastScenario || lastScenarioFilePath !== filePath) {
    apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    return null;
  }

  if (!Array.isArray(lastScenario) || lastScenarioIndex < 0 || lastScenarioIndex >= lastScenario.length) {
    const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;
    apiResult.style.color = "#3fb950";
    apiResult.textContent = totalSteps > 0
      ? `✅ Všetkých ${totalSteps} krokov scenára bolo úspešne dokončených.`
      : "✅ Všetky kroky scenára boli úspešne dokončené.";
    return null;
  }

  const step = lastScenario[lastScenarioIndex];
  if (!step) {
    apiResult.textContent = "Neplatný krok scenára.";
    return null;
  }

  const inspected = chrome.devtools?.inspectedWindow;
  const tabId = inspected?.tabId;
  if (tabId == null) {
    apiResult.textContent = "TabId nie je k dispozícii.";
    return null;
  }

  return { apiResult, filePath, step, tabId };
}

async function runCurrentStepAssertions(phase = "before") {
  const context = getCurrentStepContext();
  if (!context) return;
  const { step, tabId } = context;
  if (getStepPhaseAssertionLines(step, phase).length === 0) {
    lastAssertResultsByStep.set(lastScenarioIndex, { ...(lastAssertResultsByStep.get(lastScenarioIndex) || {}), [phase]: { passed: true, results: [] } });
    syncCurrentStepModeAndAssertions();
    return;
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;

  const storePhaseResults = (results) => {
    lastAssertResultsByStep.set(lastScenarioIndex, { ...(lastAssertResultsByStep.get(lastScenarioIndex) || {}), [phase]: results });
  };

  chrome.tabs.sendMessage(tabId, { type: "ALF_RUN_ASSERTIONS", phase, steps: resolveVarsInScenario(lastScenario), stepIndex: lastScenarioIndex }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "chyba pri posielaní assert správy:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      stopAutoRun("zastavený kvôli chybe: assert správa zlyhala", true);
      updateActionButtonState();
      return;
    }

    if (!response || !response.ok) {
      const err = response && response.error ? response.error : "Nepodarilo sa vyhodnotiť assertácie.";
      storePhaseResults({ passed: false, results: [{ fn: "", args: [], passed: false, raw: "(assert-runtime)", error: err }] });
      stopAutoRun("zastavený kvôli chybe: assert sa nedal vyhodnotiť", true);
      syncCurrentStepModeAndAssertions();
      return;
    }

    const assertResults = response.assertResults || { passed: true, results: [] };
    harvestCapturedVars(assertResults);
    for (const resultItem of assertResults.results || []) {
      if (!resultItem.passed) {
        const reason = resultItem.error || assertionFailureText(resultItem);
        const errorMsg = reason ? ` — ${reason}` : "";
        alfLog("error", `assertion failed: [${resultItem.raw}]${errorMsg}`);
      } else if ((resultItem.fn === "captureFromDti" || resultItem.fn === "captureFromText") && resultItem.info) {
        alfLog("info", `${stepLogPrefix()} captured {{${resultItem.info.varName}}} = "${resultItem.info.captured}"`);
      } else if (resultItem.info && resultItem.info.message) {
        alfLog("warn", `assertions INFO: ${resultItem.info.message}`, { __alfLogOptions: true, consoleOnly: true });
      }
    }

    const assertTotal = (assertResults.results || []).length;
    const assertPassed = (assertResults.results || []).filter((r) => r.passed).length;
    alfLog("info", `${stepLogPrefix()} assert ${phase} ${assertPassed}/${assertTotal} OK`);
    storePhaseResults(assertResults);
    if ((assertResults.results || []).some((r) => !r.passed)) stopAutoRun("zastavený kvôli chybe: assert nepresiel", true);
    syncCurrentStepModeAndAssertions();
  });
}

async function runCurrentStepMap() {
  const context = getCurrentStepContext();
  if (!context) return;
  const { tabId } = context;

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  alfLog("info", `${stepLogPrefix()} map`);

  chrome.tabs.sendMessage(tabId, { type: "ALF_RUN_MAP", steps: resolveVarsInScenario(lastScenario), stepIndex: lastScenarioIndex }, (response) => {
    if (chrome.runtime.lastError || !response || !response.ok) {
      const reason = chrome.runtime.lastError ? chrome.runtime.lastError.message : response && response.error;
      alfLog("warn", `${stepLogPrefix()} map zlyhal: ${reason || "content script neodpovedal"}`);
      stopAutoRun("zastavený kvôli chybe: map zlyhal", true);
      updateActionButtonState();
      return;
    }

    const missing = Array.isArray(response.mapMissing) ? response.mapMissing : [];
    lastRunStateByStep.set(lastScenarioIndex, { ...(lastRunStateByStep.get(lastScenarioIndex) || {}), mapDone: true, mapMissing: missing });
    if (missing.length > 0) {
      alfLog("warn", `${stepLogPrefix()} map: element sa nenašiel pre ${missing.join(", ")}`);
      stopAutoRun(`zastavený kvôli chybe: map — element sa nenašiel pre ${missing.join(", ")}`, true);
    }
    syncCurrentStepModeAndAssertions();
  });
}

async function runCurrentStepAction() {
  const context = getCurrentStepContext();
  if (!context) return;
  const { apiResult, step, tabId } = context;

  if (isClientSwitchStep(step)) {
    const presetSelect = $("presetSelect");
    const presetName = presetSelect ? presetSelect.value : "";
    const preset = presetName && currentPresetsMap.has(presetName) ? currentPresetsMap.get(presetName) : null;
    const nextHost = resolveClientHost(preset, step.client);
    if (!nextHost) {
      apiResult.textContent = `Preset neobsahuje host pre klienta "${step.client}".`;
      return;
    }
    alfLog("info", `switch client → ${step.client} (${nextHost})`);
    try {
      chrome.tabs.update(tabId, { url: `${nextHost}/` });
    } catch (e) {
      alfLog("warn", "nepodarilo sa prepnúť klienta:", e && e.message ? e.message : e);
    }
    const nextIndex = Math.min(lastScenarioIndex + 1, lastScenario.length);
    lastScenarioIndex = nextIndex;
    renderCurrentStepInfo(nextIndex);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
    return;
  }

  const actionName = step.action || step.actions;
  if (!actionName) {
    apiResult.textContent = "Krok scenára nemá definovanú action/actions.";
    lastScenarioIndex = Math.min(lastScenarioIndex + 1, lastScenario.length);
    renderCurrentStepInfo(lastScenarioIndex);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
    return;
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) runScenarioStepBtn.disabled = true;
  alfLog("info", `${stepLogPrefix()} action ${actionName}`);

  chrome.tabs.sendMessage(tabId, { type: "ALF_RUN_SCENARIO_ACTION", steps: resolveVarsInScenario(lastScenario), stepIndex: lastScenarioIndex }, (response) => {
    if (chrome.runtime.lastError) {
      alfLog("warn", "chyba pri posielaní správy:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      stopAutoRun("zastavený kvôli chybe: správa pre content script zlyhala", true);
      updateActionButtonState();
      return;
    }

    if (!response || !response.ok) {
      alfLog("warn", "content script nevedel spracovať action:", actionName, response);
      stopAutoRun("zastavený kvôli chybe: content script nespracoval action", true);
      updateActionButtonState();
      return;
    }

    if (response.skipped) {
      alfLog("info", `${stepLogPrefix()} skipped (condition)`);
      lastScenarioIndex = Math.min(lastScenarioIndex + 1, Array.isArray(lastScenario) ? lastScenario.length : 0);
      renderCurrentStepInfo(lastScenarioIndex);
      syncCurrentStepModeAndAssertions();
      setTimeout(() => runCurrentStepAction(), 0);
      return;
    }

    lastRunStateByStep.set(lastScenarioIndex, { ...(lastRunStateByStep.get(lastScenarioIndex) || {}), found: response.found !== false, done: response.found !== false, mapDone: true, mapMissing: [...new Set([...((lastRunStateByStep.get(lastScenarioIndex) || {}).mapMissing || []), ...(response.mapMissing || [])])] });
    if (!response.found || (response.mapMissing || []).length > 0) renderCurrentStepInfo();

    if (Array.isArray(response.mapMissing) && response.mapMissing.length > 0) {
      alfLog("warn", `${stepLogPrefix()} map: element sa nenašiel pre ${response.mapMissing.join(", ")}`);
      stopAutoRun(`zastavený kvôli chybe: map — element sa nenašiel pre ${response.mapMissing.join(", ")}`, true);
    }

    if (response.attachmentManual) {
      alfLog(
        "info",
        response.dialogAllowed === false
          ? `${stepLogPrefix()} upload — prehliadač neotvorí dialóg bez ručného kliku: klikni na ${actionName.split("#")[0]}, vyber súbor a stlač Continue`
          : `${stepLogPrefix()} upload dialog — vyber súbor a stlač Continue`,
      );
      pauseAutoRun("dialóg na nahratie súboru — vyber súbor a stlač Continue");
    }

    if (!response.found) {
      alfLog("warn", "element with data-test-id was not found:", actionName);
      stopAutoRun(`zastavený kvôli chybe: element "${actionName}" sa nenašiel`, true);
      updateActionButtonState();
      return;
    }

    const totalSteps = Array.isArray(lastScenario) ? lastScenario.length : 0;
    const nextIndex = Math.min(lastScenarioIndex + 1, totalSteps);
    try {
      if (chrome.action && totalSteps && tabId != null) {
        chrome.action.setBadgeText({ text: `${nextIndex}/${totalSteps}`, tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge && totalSteps) stepBadge.textContent = `${nextIndex}/${totalSteps}`;
    } catch (e) {
      alfLog("warn", "nepodarilo sa aktualizovať badge:", e && e.message ? e.message : e);
    }

    const executedIdx = lastScenarioIndex;
    lastScenarioIndex = nextIndex;
    holdExecutedStepThenAdvance(executedIdx);
    syncCurrentStepModeAndAssertions();
    applyDelayForCurrentStep();
  });
}

function getDonePhases(idx) {
  const step = Array.isArray(lastScenario) ? lastScenario[idx] : null;
  return step ? getStepPhases(step).filter((phase) => isPhaseDone(idx, phase)) : [];
}

function undoPhase(idx, phase) {
  if (phase === "map") {
    lastRunStateByStep.set(idx, { ...(lastRunStateByStep.get(idx) || {}), mapDone: false, mapMissing: [] });
    return;
  }
  const results = { ...(lastAssertResultsByStep.get(idx) || {}) };
  delete results[phase];
  lastAssertResultsByStep.set(idx, results);
}

// Steps back one phase (assert before → map → assert after → action), not a whole step.
function prevScenarioStep() {
  if (!Array.isArray(lastScenario)) return;
  const doneHere = getDonePhases(lastScenarioIndex);
  if (doneHere.length > 0) {
    undoPhase(lastScenarioIndex, doneHere[doneHere.length - 1]);
  } else if (lastScenarioIndex > 0) {
    lastScenarioIndex -= 1;
    const step = lastScenario[lastScenarioIndex];
    const results = { ...(lastAssertResultsByStep.get(lastScenarioIndex) || {}) };
    for (const phase of getStepPhases(step)) {
      if (phase === "before" || phase === "after") results[phase] = results[phase] || { passed: true, results: [] };
    }
    lastAssertResultsByStep.set(lastScenarioIndex, results);
    lastRunStateByStep.set(lastScenarioIndex, { mapDone: true, mapMissing: [] });
  } else {
    return;
  }

  syncCurrentStepModeAndAssertions();

  try {
    const totalSteps = lastScenario.length;
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (chrome.action && tabId != null && totalSteps) {
      chrome.action.setBadgeText({ text: `${lastScenarioIndex}/${totalSteps}`, tabId });
    }
    const stepBadge = $("stepBadge");
    if (stepBadge) stepBadge.textContent = `${lastScenarioIndex}/${totalSteps}`;
  } catch {}
}

async function runScenarioStep() {
  if (currentStepMode === "before" || currentStepMode === "after") {
    await runCurrentStepAssertions(currentStepMode);
    return;
  }
  if (currentStepMode === "map") {
    await runCurrentStepMap();
    return;
  }
  await runCurrentStepAction();
}

async function resetScenario() {
  const apiSelect = $("apiSelect");
  const apiResult = $("apiResult");
  const filePath = apiSelect && apiSelect.value ? String(apiSelect.value) : "";

  if (!filePath || !Array.isArray(lastScenario) || lastScenarioFilePath !== filePath) {
    if (apiResult) apiResult.textContent = "Vyber scenár v comboboxe – načíta sa a presmeruje na start.";
    updateActionButtonState();
    return;
  }

  lastScenarioIndex = 0;
  scenarioVariables = {};
  lastAssertResultsByStep.clear();
  lastRunStateByStep.clear();
  renderCurrentStepInfo(0);
  syncCurrentStepModeAndAssertions();
  applyDelayForCurrentStep();

  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    const totalSteps = lastScenario.length;
    if (chrome.action && tabId != null && totalSteps) chrome.action.setBadgeText({ text: `0/${totalSteps}`, tabId });
    const stepBadge = $("stepBadge");
    if (stepBadge && totalSteps) stepBadge.textContent = `0/${totalSteps}`;
  } catch (e) {
    alfLog("warn", "nepodarilo sa resetnúť badge:", e && e.message ? e.message : e);
  }

  try {
    const startStep = Array.isArray(lastScenario) && lastScenario.length > 0 ? lastScenario[0] : null;
    const startUrl = getStepUrlHint(startStep) || "/";

    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;

    const currentHrefResult = await getInspectedTabUrl().catch(() => null);
    let targetOrigin = null;
    if (!getStepUrlHint(startStep)) targetOrigin = getPresetFlatHost();
    if (!targetOrigin && currentHrefResult) {
      try {
        const current = new URL(currentHrefResult);
        targetOrigin = current.origin;
      } catch {
        targetOrigin = null;
      }
    }

    if (!startUrl.startsWith("http") && !targetOrigin) return;

    let targetUrl;
    if (startUrl.startsWith("http")) {
      targetUrl = startUrl;
    } else {
      targetUrl = startUrl.startsWith("/") ? targetOrigin + startUrl : targetOrigin + "/" + startUrl;
    }

    chrome.tabs.update(tabId, { url: targetUrl });
  } catch (e) {
    alfLog("warn", "nepodarilo sa presmerovať po reset:", e && e.message ? e.message : e);
  }
}



let autoRunTimer = null;
let autoRunPaused = false;
let autoRunIntervalMs = 2000;

function isScenarioFinished() {
  return !Array.isArray(lastScenario) || lastScenarioIndex >= lastScenario.length;
}

// Countdown bar: shrinks over one interval and restarts on every tick.
function restartAutoProgress() {
  const bar = $("autoProgress");
  if (!bar) return;
  const running = autoRunTimer !== null;
  bar.hidden = !running;
  bar.classList.toggle("paused", running && autoRunPaused);
  const fill = bar.firstElementChild;
  if (!fill) return;
  bar.style.setProperty("--auto-interval", `${autoRunIntervalMs}ms`);
  fill.style.animation = "none";
  void fill.offsetWidth;
  fill.style.animation = "";
}

function renderAutoRunButton() {
  const autoRunBtn = $("autoRunBtn");
  if (!autoRunBtn) return;
  const running = autoRunTimer !== null;
  autoRunBtn.textContent = running ? (autoRunPaused ? "▶ Continue" : "■ Stop auto") : "▶ Run auto";
  autoRunBtn.classList.toggle("mode-assert", running && !autoRunPaused);
  autoRunBtn.classList.toggle("auto-paused", running && autoRunPaused);
  restartAutoProgress();
}

function autoRunTick() {
  if (autoRunPaused) return;
  restartAutoProgress();
  if (isScenarioFinished()) {
    stopAutoRun("zastavený: scenár skončil");
    return;
  }
  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (!runScenarioStepBtn || runScenarioStepBtn.disabled) return;
  runScenarioStep();
}

function formatAutoInterval(intervalMs) {
  return `${intervalMs / 1000} s`;
}

function startAutoRun() {
  stopAutoRun();
  const intervalSelect = $("autoIntervalSelect");
  const intervalMs = Number(intervalSelect && intervalSelect.value) || 2000;
  autoRunPaused = false;
  autoRunIntervalMs = intervalMs;
  autoRunTimer = setInterval(autoRunTick, intervalMs);
  renderAutoRunButton();
  alfLog("info", `AUTOTEST zapnutý — interval kroku ${formatAutoInterval(intervalMs)}`);
}

function stopAutoRun(reason, isError) {
  if (autoRunTimer === null) return;
  clearInterval(autoRunTimer);
  autoRunTimer = null;
  autoRunPaused = false;
  renderAutoRunButton();
  alfLog(isError ? "warn" : "info", `AUTOTEST ${reason || "vypnutý"} (interval kroku ${formatAutoInterval(autoRunIntervalMs)})`);
}

function pauseAutoRun(reason) {
  if (autoRunTimer === null || autoRunPaused) return;
  autoRunPaused = true;
  renderAutoRunButton();
  alfLog("warn", `AUTOTEST pozastavený: ${reason} (interval kroku ${formatAutoInterval(autoRunIntervalMs)})`);
}

function resumeAutoRun() {
  if (autoRunTimer === null || !autoRunPaused) return;
  autoRunPaused = false;
  clearInterval(autoRunTimer);
  autoRunTimer = setInterval(autoRunTick, autoRunIntervalMs);
  renderAutoRunButton();
  alfLog("info", `AUTOTEST obnovený (Continue) (interval kroku ${formatAutoInterval(autoRunIntervalMs)})`);
}

function toggleAutoRun() {
  if (autoRunTimer === null) startAutoRun();
  else if (autoRunPaused) resumeAutoRun();
  else stopAutoRun();
}
