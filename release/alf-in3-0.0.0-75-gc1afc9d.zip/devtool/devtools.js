async function init() {
  initCustomDropdowns();
  const apiSelect = $("apiSelect");

  try {
    const versionEl = $("alfVersion");
    if (versionEl && chrome.runtime && chrome.runtime.getManifest) {
      const manifest = chrome.runtime.getManifest();
      if (manifest && manifest.version) {
        versionEl.textContent = `v${manifest.version}`;
      }
    }
  } catch {
    // verzia je len kozmetická informácia
  }

  currentBaseUrl = (await loadStoredUrl()) || "https://a3.ugkk.dev/";
  await loadProjectsIntoSelect();
  await loadAmsInfoIntoUi();
  await loadPresetsIntoSelect();
  await loadSuitesIntoSelect();
  await loadScenariosIntoSelect();

  const presetSelect = $("presetSelect");
  if (presetSelect) {
    presetSelect.addEventListener("change", async () => {
      updatePresetDescription();
      await saveStoredValue(STORAGE_KEY_PRESET, presetSelect.value);
      await loadScenariosIntoSelect();
      const selectedScenario = apiSelect && apiSelect.value ? String(apiSelect.value).trim() : "";
      if (!selectedScenario) {
        const presetId = presetSelect.value;
        if (presetId && currentPresetsMap.has(presetId)) {
          const preset = currentPresetsMap.get(presetId);
          if (preset.env) {
            let newUrl = preset.env.trim();
            if (!newUrl.startsWith("http")) newUrl = "https://" + newUrl;
            try {
              const inspected = chrome.devtools?.inspectedWindow;
              const tabId = inspected?.tabId;
              if (tabId != null) chrome.tabs.update(tabId, { url: newUrl });
            } catch {}
          }
        }
        return;
      }
      await loadScenario();
    });
  }

  const projectSelect = $("projectSelect");
  if (projectSelect) {
    projectSelect.addEventListener("change", async () => {
      currentProject = projectSelect.value;
      await saveProject(currentProject);

      lastScenario = null;
      lastScenarioIndex = -1;
      lastScenarioFilePath = null;
      lastAssertResultsByStep.clear();
      setPrimaryButtonMode(STEP_MODE_ACTION);

      const apiResult = $("apiResult");
      if (apiResult) apiResult.textContent = "";
      renderAssertionResults(null);

      try {
        const inspected = chrome.devtools?.inspectedWindow;
        const tabId = inspected?.tabId;
        if (tabId != null) chrome.action.setBadgeText({ text: "", tabId });
        const stepBadge = $("stepBadge");
        if (stepBadge) stepBadge.textContent = "0/0";
      } catch (e) {
        alfLog("warn", "ALF DevTools – nepodarilo sa vyčistiť badge:", e && e.message ? e.message : e);
      }

      await loadPresetsIntoSelect();
      await loadSuitesIntoSelect();
      await loadScenariosIntoSelect();
      updateActionButtonState();
    });
  }

  const refreshPresetsBtn = $("refreshPresetsBtn");
  if (refreshPresetsBtn) {
    refreshPresetsBtn.addEventListener("click", async () => {
      await loadPresetsIntoSelect();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const suiteSelect = $("suiteSelect");
  if (suiteSelect) {
    suiteSelect.addEventListener("change", async () => {
      await saveStoredValue(STORAGE_KEY_SUITE, suiteSelect.value);
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const refreshSuitesBtn = $("refreshSuitesBtn");
  if (refreshSuitesBtn) {
    refreshSuitesBtn.addEventListener("click", async () => {
      await loadSuitesIntoSelect();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const runScenarioStepBtn = $("runScenarioStepBtn");
  if (runScenarioStepBtn) {
    runScenarioStepBtn.disabled = true;
    setPrimaryButtonMode(STEP_MODE_ACTION);
    runScenarioStepBtn.addEventListener("click", runScenarioStep);
  }

  const prevScenarioStepBtn = $("prevScenarioStepBtn");
  if (prevScenarioStepBtn) {
    prevScenarioStepBtn.disabled = true;
    prevScenarioStepBtn.addEventListener("click", prevScenarioStep);
  }

  const resetScenarioBtn = $("resetScenarioBtn");
  if (resetScenarioBtn) {
    resetScenarioBtn.addEventListener("click", resetScenario);
  }

  const refreshScenariosBtn = $("refreshScenariosBtn");
  if (refreshScenariosBtn) {
    refreshScenariosBtn.addEventListener("click", async () => {
      await loadAmsInfoIntoUi();
      await loadScenariosIntoSelect();
      if (apiSelect && apiSelect.value) {
        await loadScenario();
      }
    });
  }

  const logClearBtn = $("logClearBtn");
  if (logClearBtn) {
    logClearBtn.addEventListener("click", () => {
      const logArea = $("logArea");
      if (logArea) logArea.innerHTML = "";
    });
  }

  const highlightDtiCheckbox = $("highlightDtiCheckbox");
  if (highlightDtiCheckbox) {
    const storedHighlight = await loadStoredValue(STORAGE_KEY_HIGHLIGHT);
    highlightDtiCheckbox.checked = storedHighlight === true || storedHighlight === "true";
    if (highlightDtiCheckbox.checked) sendHighlightToggle(true);

    highlightDtiCheckbox.addEventListener("change", async () => {
      const enabled = highlightDtiCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_HIGHLIGHT, enabled);
      sendHighlightToggle(enabled);
    });
  }

  const testLabelBelowCheckbox = $("testLabelBelowCheckbox");
  if (testLabelBelowCheckbox) {
    const storedTestLabelBelow = await loadStoredValue(STORAGE_KEY_TEST_LABEL_BELOW);
    testLabelBelowCheckbox.checked = storedTestLabelBelow === true || storedTestLabelBelow === "true";
    sendTestLabelBelowToggle(testLabelBelowCheckbox.checked);

    testLabelBelowCheckbox.addEventListener("change", async () => {
      const enabled = testLabelBelowCheckbox.checked;
      await saveStoredValue(STORAGE_KEY_TEST_LABEL_BELOW, enabled);
      sendTestLabelBelowToggle(enabled);
    });
  }

  apiSelect.addEventListener("change", async () => {
    updateScenarioDescription();
    await saveStoredValue(STORAGE_KEY_FLOW, apiSelect.value);
    const apiResult = $("apiResult");

    apiResult.textContent = "";
    renderAssertionResults(null);
    lastScenario = null;
    lastScenarioIndex = -1;
    lastScenarioFilePath = null;
    lastAssertResultsByStep.clear();
    setPrimaryButtonMode(STEP_MODE_ACTION);

    try {
      const inspected = chrome.devtools?.inspectedWindow;
      const tabId = inspected?.tabId;
      if (tabId != null) {
        chrome.action.setBadgeText({ text: "", tabId });
      }
      const stepBadge = $("stepBadge");
      if (stepBadge) {
        stepBadge.textContent = "0/0";
      }
    } catch (e) {
      alfLog("warn", "ALF DevTools – nepodarilo sa vyčistiť badge:", e && e.message ? e.message : e);
    }

    loadScenario();
    updateActionButtonState();
  });
}

function sendHighlightToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_TOGGLE_HIGHLIGHT", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "ALF DevTools – highlight toggle:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "ALF DevTools – highlight toggle výnimka:", e && e.message ? e.message : e);
  }
}

function sendTestLabelBelowToggle(enabled) {
  try {
    const inspected = chrome.devtools?.inspectedWindow;
    const tabId = inspected?.tabId;
    if (tabId == null) return;
    chrome.tabs.sendMessage(tabId, { type: "ALF_SET_TEST_LABEL_BELOW", enabled }, () => {
      if (chrome.runtime.lastError) {
        alfLog("warn", "ALF DevTools – test label position:", chrome.runtime.lastError.message || chrome.runtime.lastError);
      }
    });
  } catch (e) {
    alfLog("warn", "ALF DevTools – test label position výnimka:", e && e.message ? e.message : e);
  }
}

document.addEventListener("DOMContentLoaded", init);
