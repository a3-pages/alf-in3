// `external` of a step: the recipe primitives the engine (arch-it3ct external-catalog.js) already filled with values.
// The panel outlives page navigations, so it drives the recipe: host waits are checked on the tab,
// element primitives are injected into the page and retried while the next page is still loading.

// UPVS's full-page loader (#loaderOverlay) has been timed at ~71s over VPN on a slow day — far past the
// old 40s budget, which failed the step correctly detecting the loader was still there, not too early.
const EXTERNAL_STEP_TIMEOUT_MS = 120000;
const EXTERNAL_POLL_MS = 300;

const externalSleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Says what the budget was and how long it actually took, so a timeout log reads e.g.
// "ALF čakal 120 s, no trvalo to 142 s" instead of a bare "sa nenašiel" that looks like a missing element.
function describeExternalTimeout(startedAt) {
  const budgetS = Math.round(EXTERNAL_STEP_TIMEOUT_MS / 1000);
  const elapsedS = Math.round((Date.now() - startedAt) / 1000);
  return `ALF čakal ${budgetS} s, no trvalo to ${elapsedS} s`;
}

function describeExternalPrimitive(primitive) {
  const parts = [primitive.do, primitive.css, primitive.text, primitive.host, primitive.file, primitive.secret ? "***" : primitive.value];
  return parts.filter((part) => part !== undefined).join(" ");
}

function externalHostOf(url) {
  try {
    return new URL(url).host;
  } catch (e) {
    return "";
  }
}

async function waitForTabHost(tabId, host, { untilLoaded = true } = {}) {
  const startedAt = Date.now();
  const deadline = startedAt + EXTERNAL_STEP_TIMEOUT_MS;
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId);
    if (externalHostOf(tab.url) === host && (!untilLoaded || tab.status === "complete")) return;
    await externalSleep(EXTERNAL_POLL_MS);
  }
  throw new Error(`stránka sa nedostala na „${host}“ (${describeExternalTimeout(startedAt)})`);
}

// Runs inside the page (injected with chrome.scripting, so it does not depend on the content script version); must stay self-contained.
function externalPagePrimitive(primitive) {
  const normalized = (text) => String(text || "").replace(/\s+/g, " ").trim();
  if (primitive.do === "click") {
    const el = document.querySelector(primitive.css);
    if (!el) return false;
    el.click();
    return true;
  }
  if (primitive.do === "clickText") {
    const el = Array.from(document.querySelectorAll(primitive.css)).find((candidate) => normalized(candidate.textContent).includes(normalized(primitive.text)));
    if (!el) return false;
    el.click();
    return true;
  }
  if (primitive.do === "fill") {
    const el = document.querySelector(primitive.css);
    if (!el) return false;
    const valueSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    valueSetter.call(el, primitive.value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  return false;
}

async function runPrimitiveInPage(tabId, primitive) {
  try {
    const [injection] = await chrome.scripting.executeScript({ target: { tabId }, func: externalPagePrimitive, args: [primitive] });
    return Boolean(injection && injection.result);
  } catch (error) {
    return false;
  }
}

async function runElementPrimitive(tabId, primitive) {
  const startedAt = Date.now();
  const deadline = startedAt + EXTERNAL_STEP_TIMEOUT_MS;
  while (Date.now() < deadline) {
    if (await runPrimitiveInPage(tabId, primitive)) return;
    await externalSleep(EXTERNAL_POLL_MS);
  }
  throw new Error(`element „${primitive.css}“ sa nenašiel (${describeExternalTimeout(startedAt)})`);
}

// Runs inside the page: true once no visible element matches css (a missing element counts as gone).
// A full-page loader can be hidden by all sorts of CSS (opacity, visibility, an off-screen position, an
// ancestor's display:none, [hidden]…) without being removed from the DOM, so a size/style guess of our own
// keeps missing cases. checkVisibility() is the browser's own answer to "is this actually visible", and
// falls back to a plain size check only where it is unsupported.
function externalPageIsGone(css) {
  return Array.from(document.querySelectorAll(css)).every((el) => {
    if (typeof el.checkVisibility === "function") {
      return !el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true });
    }
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || parseFloat(style.opacity) === 0) return true;
    return !(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  });
}

async function waitForTabGone(tabId, css) {
  const startedAt = Date.now();
  const deadline = startedAt + EXTERNAL_STEP_TIMEOUT_MS;
  while (Date.now() < deadline) {
    try {
      const [injection] = await chrome.scripting.executeScript({ target: { tabId }, func: externalPageIsGone, args: [css] });
      if (injection && injection.result) return;
    } catch (error) {
      /* the page is navigating, check again */
    }
    await externalSleep(EXTERNAL_POLL_MS);
  }
  throw new Error(`element „${css}“ nezmizol (${describeExternalTimeout(startedAt)})`);
}

async function runExternalPrimitive(tabId, primitive, clientHost) {
  if (primitive.do === "armFakeAutogram") return;
  if (primitive.do === "waitForAutogramSigned") {
    pauseAutoRun("podpíš dokument v Autograme a stlač Continue");
    return;
  }
  if (primitive.do === "waitForHost") return waitForTabHost(tabId, primitive.host, { untilLoaded: false });
  if (primitive.do === "waitForGone") return waitForTabGone(tabId, primitive.css);
  if (primitive.do === "waitForClientHost") return waitForTabHost(tabId, clientHost);
  return runElementPrimitive(tabId, primitive);
}

// Runs every call of `step.external` in order; throws an Error naming the adapter and primitive that failed.
async function runExternalCalls(tabId, calls, clientHost) {
  for (const call of calls || []) {
    for (const primitive of call.recipe) {
      const waits = primitive.do === "waitForHost" || primitive.do === "waitForGone" || primitive.do === "waitForClientHost" || primitive.do === "click" || primitive.do === "clickText" || primitive.do === "fill";
      const budgetNote = waits ? ` (max ${Math.round(EXTERNAL_STEP_TIMEOUT_MS / 1000)} s)` : "";
      alfLog("info", `external ${call.name}: ${describeExternalPrimitive(primitive)}${budgetNote}`);
      try {
        await runExternalPrimitive(tabId, primitive, clientHost);
      } catch (error) {
        throw new Error(`external „${call.name}“, krok „${describeExternalPrimitive(primitive)}“: ${error.message}`);
      }
    }
  }
}
