// Custom dropdown (select) components for ALF DevTools.

const ENV_COLORS = {
  "dev-1": "#2e86c1", "dev-2": "#2874a6", "dev-3": "#1a6fa0",
  "sit-1": "#e67e22", "sit-2": "#ca6f1e",
  "beta":  "#8e44ad",
  "prod":  "#27ae60",
};

function getEnvBadgeColor(env) {
  if (!env) return "#30363d";
  return ENV_COLORS[env.toLowerCase()] || "#30363d";
}

function renderEnvBadge(env) {
  if (!env) return "";
  const color = getEnvBadgeColor(env);
  return `<span style="background:${color};color:#fff;border-radius:4px;padding:1px 6px;font-size:10px;font-weight:600;white-space:nowrap;">${env}</span>`;
}

function renderPresetOptionHtml(opt, compact) {
  if (!opt || !opt.value) return `<span style="color:#8b949e">${opt ? opt.textContent : ""}</span>`;
  const env = opt.dataset.env || "";
  const title = opt.textContent;
  return `<span style="display:inline-flex;align-items:center;gap:6px;">${renderEnvBadge(env)}<span>${title}</span></span>`;
}

function renderFlowOptionHtml(opt) {
  if (!opt || !opt.value) return `<span style="color:#8b949e">${opt ? opt.textContent : ""}</span>`;
  let text = opt.textContent;

  const presetEl = document.getElementById("presetSelect");
  const envTag = presetEl && presetEl.selectedIndex >= 0 ? (presetEl.options[presetEl.selectedIndex].dataset.env || "") : "";
  if (envTag && text.startsWith(envTag + "/")) text = text.slice(envTag.length + 1);

  const parts = text.split("/");
  if (parts.length === 1) return `<span style="font-weight:600;">${parts[0]}</span>`;

  const name = parts[parts.length - 1];
  const folders = parts.slice(0, -1);
  return `<span style="display:inline-flex;align-items:center;gap:5px;flex-wrap:wrap;line-height:1.4;">` +
    folders.map(f => `<span style="color:#8b949e;font-size:11px;">${f}</span><span style="color:#8b949e;">»</span>`).join("") +
    `<span style="font-weight:600;">${name}</span>` +
    `</span>`;
}

function renderSuiteOptionHtml(opt) {
  if (!opt) return "";
  if (!opt.value) return `<span style="color:#8b949e">${opt.textContent}</span>`;
  return `<span>${opt.textContent}</span>`;
}

const CUSTOM_SELECT_CONFIGS = {
  presetSelect: { renderOption: renderPresetOptionHtml, renderSelected: renderPresetOptionHtml },
  apiSelect: { renderOption: renderFlowOptionHtml, renderSelected: renderFlowOptionHtml },
  suiteSelect: { renderOption: renderSuiteOptionHtml, renderSelected: renderSuiteOptionHtml },
};

function syncCustomDropdown(selectId) {
  const select = document.getElementById(selectId);
  const wrapper = document.getElementById(selectId + "-custom");
  if (!select || !wrapper) return;
  const config = CUSTOM_SELECT_CONFIGS[selectId];
  if (!config) return;

  const dropdown = wrapper.querySelector(".csd-dropdown");
  if (!dropdown) return;

  dropdown.innerHTML = "";
  for (const opt of select.options) {
    const item = document.createElement("div");
    item.className = "csd-option" + (opt.value === select.value ? " csd-selected" : "");
    item.dataset.value = opt.value;
    item.innerHTML = config.renderOption(opt);
    item.addEventListener("mousedown", (e) => {
      e.preventDefault();
      select.value = opt.value;
      select.dispatchEvent(new Event("change", { bubbles: true }));
      syncCustomDropdownSelected(selectId);
      wrapper.classList.remove("csd-open");
    });
    dropdown.appendChild(item);
  }

  syncCustomDropdownSelected(selectId);
}

function syncCustomDropdownSelected(selectId) {
  const select = document.getElementById(selectId);
  const wrapper = document.getElementById(selectId + "-custom");
  if (!select || !wrapper) return;
  const config = CUSTOM_SELECT_CONFIGS[selectId];
  if (!config) return;

  const triggerLabel = wrapper.querySelector(".csd-trigger-label");
  if (triggerLabel) {
    const selectedOpt = select.selectedIndex >= 0 ? select.options[select.selectedIndex] : null;
    triggerLabel.innerHTML = config.renderSelected(selectedOpt);
  }

  const items = wrapper.querySelectorAll(".csd-option");
  items.forEach((item) => {
    item.classList.toggle("csd-selected", item.dataset.value === select.value);
  });
}

function initCustomDropdowns() {
  for (const selectId of Object.keys(CUSTOM_SELECT_CONFIGS)) {
    const select = document.getElementById(selectId);
    if (!select) continue;

    select.style.display = "none";

    const wrapper = document.createElement("div");
    wrapper.id = selectId + "-custom";
    wrapper.className = "csd-wrapper";
    wrapper.innerHTML =
      `<div class="csd-trigger"><span class="csd-trigger-label"></span><span class="csd-arrow">▾</span></div>` +
      `<div class="csd-dropdown"></div>`;

    select.parentNode.insertBefore(wrapper, select.nextSibling);

    wrapper.querySelector(".csd-trigger").addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = wrapper.classList.contains("csd-open");
      document.querySelectorAll(".csd-wrapper.csd-open").forEach((w) => w.classList.remove("csd-open"));
      if (!isOpen) {
        wrapper.classList.add("csd-open");
        syncCustomDropdown(selectId);
      }
    });

    syncCustomDropdown(selectId);
  }

  document.addEventListener("click", () => {
    document.querySelectorAll(".csd-wrapper.csd-open").forEach((w) => w.classList.remove("csd-open"));
  });
}
