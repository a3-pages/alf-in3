/**
 * APS scraper: scans the page for [data-aps] markers, builds a FULL APS
 * screen YAML document (screen.page/width/template/theme/block.main) - the
 * aps-editor now edits the whole document as one buffer, not just
 * block.main - and returns it base64url-encoded so it can be pasted into
 * the editor's /@/aps/edit/<base64> URL. See APS-SCRAPER.md.
 */

function __apsScanElements() {
  return Array.prototype.slice.call(document.querySelectorAll("[data-aps]"));
}

function __apsParseElement(el) {
  const raw = el.dataset.aps;
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      const name = Object.keys(parsed)[0];
      return { name, props: __apsMapProps(name, parsed[name] || {}) };
    }
  } catch (e) {
    // not JSON — plain component-name string case, fall through below
  }

  const variant = el.dataset.apsVariant;
  return { name: raw, props: variant ? { variant } : {} };
}

// Renders only read cmp.value (not cmp.modelValue) - see arch-r3po src/component/is/input.js.
// Every other prop (id/description/dataTestId/etc.) is kept as-is: harmless to the
// renderer (unused props are simply never read) and useful context for a human
// editing the scraped YAML afterwards.
function __apsMapProps(name, props) {
  const out = Object.assign({}, props);
  if ("modelValue" in out) {
    out.value = out.modelValue;
    delete out.modelValue;
  }
  return out;
}

function __apsYamlScalar(v) {
  if (v === null || v === undefined) return "null";
  if (typeof v === "boolean" || typeof v === "number") return String(v);
  return JSON.stringify(String(v));
}

// Prop-less components must serialize as "{}", never a bare scalar list item -
// arch-r3po's renderers do unguarded cmp.someProp access expecting an object.
function __apsBuildYamlList(entries) {
  return entries.map(({ name, props }) => {
    const keys = Object.keys(props);
    if (keys.length === 0) {
      return `- ${name}: {}`;
    }
    const propLines = keys.map(k => `        ${k}: ${__apsYamlScalar(props[k])}`);
    return [`- ${name}:`, ...propLines].join("\n");
  }).join("\n");
}

function __apsEncodeBase64Url(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = "";
  bytes.forEach(b => { binary += String.fromCharCode(b); });
  const b64 = btoa(binary);
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function __apsIndentLines(text, indent) {
  return text.split("\n").map((line) => (line.length ? indent + line : line)).join("\n");
}

// Zabalí naskrapovaný zoznam do plnohodnotného "screen:" dokumentu (tak, ako
// ho teraz edituje aps-editor v jednom bufferi) - page/width/template/theme
// sú rozumné defaulty, ktoré si používateľ v editore môže rovno prepísať.
function __apsBuildFullYaml(entries) {
  const mainYaml = __apsBuildYamlList(entries);
  const mainSection = mainYaml.trim().length === 0
    ? "    main: []"
    : "    main:\n" + __apsIndentLines(mainYaml, "    ");

  return [
    "screen:",
    `  page: ${JSON.stringify(document.title || "Scraped page")}`,
    `  width: ${window.innerWidth || 1220}`,
    `  template: "is"`,
    `  theme: "light"`,
    "  debug: false",
    "  block:",
    mainSection,
  ].join("\n");
}

function __apsScrape() {
  const entries = __apsScanElements().map(__apsParseElement);
  const yaml = __apsBuildFullYaml(entries);
  const base64 = __apsEncodeBase64Url(yaml);
  return { entries, yaml, base64 };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "ALF_SCRAPE_APS") return;
  try {
    const { entries, base64 } = __apsScrape();
    sendResponse({ ok: true, base64, count: entries.length });
  } catch (e) {
    console.error("ALF content script – aps scrape error:", e);
    sendResponse({ ok: false, error: String(e) });
  }
  return true;
});
